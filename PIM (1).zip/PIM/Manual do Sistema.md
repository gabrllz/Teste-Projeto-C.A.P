# Manual do Sistema

## Torra Torra | Contas a Pagar

Este manual explica como usar o módulo acadêmico de Contas a Pagar. O sistema foi desenvolvido em C e armazena seus dados no PostgreSQL.

## Objetivo do módulo

O módulo organiza despesas, títulos e parcelas a pagar. Também permite registrar e cancelar pagamentos, acompanhar o saldo da conta principal e consultar relatórios por período.

O fluxo mais comum é: o módulo de Compras disponibiliza um título; Contas a Pagar consulta esse título, cadastra as parcelas, acompanha os vencimentos e registra os pagamentos.

## Antes de iniciar

1. Confirme que o PostgreSQL está iniciado e que o banco `torra_db` está disponível.
2. Abra a pasta do projeto `PIM` no VS Code.
3. Compile pelo atalho configurado no projeto (`Ctrl+Shift+B`) e aguarde a conclusão.
4. Abra o terminal integrado do VS Code e execute `.\TorraContas.exe` na pasta principal do projeto.

Se o programa não conectar, confira se o serviço do PostgreSQL está ativo, se o banco existe e se os dados de conexão configurados no projeto correspondem ao seu ambiente.

## Menu principal

| Opção | Área | O que permite fazer |
|---|---|---|
| 1 | Painel financeiro | Consultar saldo, títulos em aberto, parcelas vencidas e próximos vencimentos. |
| 2 | Despesas | Cadastrar, listar, alterar e excluir despesas. |
| 3 | Títulos a pagar | Consultar títulos disponibilizados pelo processo de Compras. |
| 4 | Parcelas a pagar | Cadastrar, consultar, alterar e excluir parcelas. |
| 5 | Pagamentos | Consultar parcelas pendentes, registrar ou cancelar pagamentos e consultar o histórico. |
| 6 | Saldo bancário | Consultar, adicionar ou retirar saldo da conta principal. |
| 7 | Relatórios | Consultar pagamentos, títulos, despesas e parcelas por período. |
| 0 | Sair | Encerrar o programa. |

Digite o número da opção e pressione Enter. Nos submenus, a opção `0` retorna ao menu anterior.

## Despesas

No menu principal, escolha **2. Despesas**.

### Cadastrar

1. Escolha **1. Cadastrar despesa**.
2. Informe o ID do fornecedor. Digite `0` se a despesa não tiver fornecedor associado.
3. Informe a descrição e o tipo, que deve ser `fixa` ou `variavel`.
4. Digite a data de competência no formato `AAAA-MM-DD`, por exemplo `2026-10-30`.
5. Informe um valor numérico maior que zero, usando ponto decimal, como `125.50`.

A data precisa existir no calendário. A listagem mostra a situação da despesa de acordo com os títulos e pagamentos associados: sem título, pendente, parcialmente paga, vencida ou paga.

### Consultar, alterar ou excluir

- Escolha **2** para listar despesas.
- Escolha **3** para alterar os dados de uma despesa existente.
- Escolha **4** para excluir. O programa pede confirmação; se houver título vinculado, o banco pode impedir a exclusão para preservar o relacionamento.

## Títulos a pagar

Escolha **3. Títulos a pagar** e depois **1. Consultar títulos**. A lista mostra os títulos existentes, o fornecedor, a origem (pedido de compra ou despesa), a data de emissão, o valor total e o status.

Este módulo consulta os títulos. O cadastro de fornecedores, pedidos de compra, formas de pagamento e a criação dos títulos pertencem a outros módulos do projeto.

## Parcelas a pagar

Uma parcela representa uma parte do valor de um título, com seu próprio vencimento. Consulte primeiro os títulos para obter o ID correto.

### Cadastrar

1. Escolha **4. Parcelas a pagar** e depois **1. Cadastrar parcela para título existente**.
2. Informe o ID do título, o número da parcela e o vencimento no formato `AAAA-MM-DD`.
3. Informe um valor positivo usando ponto decimal.

O valor da nova parcela não pode ultrapassar o saldo ainda não dividido do título. O número da parcela também não pode se repetir dentro do mesmo título.

### Consultar, alterar ou excluir

- Escolha **2** para consultar as parcelas, seus vencimentos, valores, total pago e situação.
- Escolha **3** para alterar uma parcela. Parcelas com pagamentos associados não podem ser alteradas.
- Escolha **4** para excluir uma parcela. Parcelas com pagamentos associados não podem ser excluídas.

Uma parcela vencida continua aparecendo como atrasada enquanto ainda tiver saldo a pagar.

## Pagamentos

Escolha **5. Pagamentos**.

### Consultar parcelas pendentes

Escolha **1** para ver parcelas com saldo em aberto, incluindo atrasadas ou parcialmente pagas. Anote o ID da parcela que deseja pagar.

### Registrar pagamento

1. Escolha **2. Registrar pagamento**.
2. Informe o ID da parcela.
3. Escolha uma forma de pagamento ativa pelo ID mostrado na tela.
4. Informe o valor pago com ponto decimal, por exemplo `125.50`.

O valor precisa ser maior que zero, não pode ultrapassar o saldo restante da parcela e a conta principal precisa ter saldo suficiente. Quando o registro é aceito, o sistema debita a conta, grava a data e hora e atualiza a situação da parcela e do título em uma única transação.

### Cancelar pagamento e consultar histórico

Para cancelar, escolha **3**, informe o ID do pagamento e descreva o motivo. O sistema mantém o registro no histórico, marca o pagamento como cancelado, devolve o valor ao saldo da conta e recalcula as situações relacionadas.

Para conferir pagamentos realizados e cancelados, escolha **4. Consultar histórico**. O histórico apresenta a data, o título, a parcela, a forma, a conta, o valor, o status e o motivo do cancelamento, quando houver.

## Saldo bancário

Escolha **6. Saldo bancário**.

- **1. Consultar saldo** mostra o saldo disponível da conta principal.
- **2. Adicionar saldo** registra um ajuste positivo no saldo.
- **3. Retirar saldo** registra um ajuste negativo; a retirada não é aceita se o saldo for insuficiente.

Os ajustes manuais alteram o saldo atual. O módulo não mantém para eles um histórico detalhado separado. Os pagamentos registrados têm seu próprio histórico.

## Painel financeiro

Escolha **1. Painel financeiro**. O painel mostra o saldo atual e oferece consultas para:

- **Valor total pendente:** quantidade de títulos não pagos e parcelas com saldo, além do valor restante.
- **Parcelas vencidas:** total vencido e até dez das parcelas vencidas mais antigas.
- **Próximos vencimentos:** totais e parcelas para hoje até 30 dias, de 31 a 60 dias e de 61 a 90 dias. O painel também compara o saldo atual com os vencimentos dos próximos 30 dias.

Os cálculos consideram pagamentos realizados. Pagamentos cancelados não reduzem o saldo pendente.

## Relatórios

Escolha **7. Relatórios** e selecione uma opção. Informe a data inicial e a final no formato `AAAA-MM-DD`; as duas datas são incluídas no período e a inicial deve ser igual ou anterior à final.

1. **Pagamentos no período:** data, IDs, fornecedor, parcela, valor, forma, status e motivo de cancelamento.
2. **Títulos emitidos no período:** título, fornecedor, emissão, valor total e status.
3. **Despesas fixas e variáveis:** quantidade e soma dos valores por tipo e data de competência.
4. **Parcelas por vencimento:** título, fornecedor, parcela, vencimento, valor, total pago, restante e situação.

Cada relatório usa a data correspondente ao assunto: data do pagamento, emissão do título, competência da despesa ou vencimento da parcela.

## Mensagens comuns

- **Data inválida:** use `AAAA-MM-DD` e confira se o dia existe no calendário.
- **ID não encontrado:** consulte o registro relacionado e confira o número digitado.
- **Valor inválido:** use um número maior que zero com ponto decimal, como `125.50`.
- **Saldo insuficiente:** consulte o saldo da conta principal ou reduza o valor do pagamento.
- **Parcela não pode ser alterada ou excluída:** verifique se já existe pagamento associado a ela.
- **Relatório sem registros:** confira se o período informado inclui as datas dos registros.

## Escopo e limites

Este é um sistema acadêmico conectado a um banco PostgreSQL local. Ele registra as operações no banco, mas não faz transferências bancárias reais nem consulta serviços financeiros externos. Fornecedor, Pedido de Compra e Forma de Pagamento são tabelas relacionadas que pertencem a outros módulos.