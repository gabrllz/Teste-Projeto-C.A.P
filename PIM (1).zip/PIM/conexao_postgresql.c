#include <stdio.h>
#include <stdlib.h>
#include <libpq-fe.h>
 
int main(void)
{
    PGconn *conexao = PQconnectdb(
        "host=localhost "
        "port=5432 "
        "dbname=torra_db "
        "user=postgres "
        "password=123456"
    );
 
    if (PQstatus(conexao) != CONNECTION_OK)
    {
        fprintf(stderr, "Erro ao conectar ao PostgreSQL:\n%s",
                PQerrorMessage(conexao));
        PQfinish(conexao);
        return EXIT_FAILURE;
    }
 
    PGresult *resultado = PQexec(conexao, "SELECT current_database()");
 
    if (PQresultStatus(resultado) != PGRES_TUPLES_OK)
    {
        fprintf(stderr, "Erro na consulta:\n%s",
                PQerrorMessage(conexao));
        PQclear(resultado);
        PQfinish(conexao);
        return EXIT_FAILURE;
    }
 
    printf("Conectado ao banco: %s\n", PQgetvalue(resultado, 0, 0));
 
    PQclear(resultado);
    PQfinish(conexao);
    return EXIT_SUCCESS;