-- Fornecedor de teste
INSERT INTO fornecedor (
    razao_social, cnpj, email, telefone, ativo
)
VALUES (
    'Fornecedor Teste',
    '00.000.000/0001-00',
    'teste@fornecedor.com',
    '18999999999',
    TRUE
);

-- Forma de pagamento de teste
INSERT INTO forma_pagamento (
    descricao,
    ativo
)
VALUES (
    'Forma Teste',
    TRUE
);

-- Titulo de teste
INSERT INTO titulo_pagar (
    id_fornecedor,
    id_pedido_compra,
    id_despesa,
    data_emissao,
    valor_total,
    status
)
VALUES (
    1,
    NULL,
    NULL,
    CURRENT_DATE,
    1200.00,
    'pendente'
);

-- Parcelas do titulo
INSERT INTO parcela_pagar (
    id_titulo_pagar,
    numero_parcela,
    vencimento,
    valor,
    status
)
VALUES
(1, 1, '2026-11-15', 600.00, 'pendente'),
(1, 2, '2026-12-15', 600.00, 'pendente');