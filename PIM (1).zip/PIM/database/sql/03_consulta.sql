-- =============================================
-- CONSULTAS DO MODULO CONTAS A PAGAR
-- =============================================


-- FORNECEDORES
SELECT *
FROM public.fornecedor;


-- FORMAS DE PAGAMENTO
SELECT *
FROM public.forma_pagamento;


-- CONTAS BANCARIAS
SELECT *
FROM public.conta_bancaria;


-- DESPESAS
SELECT *
FROM public.despesa;


-- TITULOS A PAGAR
SELECT *
FROM public.titulo_pagar
ORDER BY id_titulo_pagar;


-- PARCELAS A PAGAR
SELECT *
FROM public.parcela_pagar
ORDER BY id_titulo_pagar, numero_parcela;


-- HISTORICO DE PAGAMENTOS
SELECT *
FROM public.pagamento
ORDER BY data_pagamento DESC;


-- TITULOS COM FORNECEDOR
SELECT
    t.id_titulo_pagar,
    f.razao_social,
    t.data_emissao,
    t.valor_total,
    t.status
FROM public.titulo_pagar t
JOIN public.fornecedor f
    ON f.id_fornecedor = t.id_fornecedor
ORDER BY t.data_emissao;


-- PARCELAS COM VALOR PAGO
SELECT
    p.id_parcela_pagar,
    p.id_titulo_pagar,
    p.numero_parcela,
    p.vencimento,
    p.valor,
    COALESCE(SUM(pg.valor_pago), 0) AS valor_pago,
    p.status
FROM public.parcela_pagar p
LEFT JOIN public.pagamento pg
    ON pg.id_parcela_pagar = p.id_parcela_pagar
    AND pg.status_pagamento = 'realizado'
GROUP BY
    p.id_parcela_pagar,
    p.id_titulo_pagar,
    p.numero_parcela,
    p.vencimento,
    p.valor,
    p.status
ORDER BY
    p.id_titulo_pagar,
    p.numero_parcela;


-- PAGAMENTOS COM FORMA DE PAGAMENTO
SELECT
    pg.id_pagamento,
    pg.id_parcela_pagar,
    fp.descricao AS forma_pagamento,
    pg.valor_pago,
    pg.data_pagamento,
    pg.status_pagamento,
    pg.motivo_cancelamento
FROM public.pagamento pg
JOIN public.forma_pagamento fp
    ON fp.id_forma_pagamento = pg.id_forma_pagamento
ORDER BY pg.data_pagamento DESC;


-- PAGAMENTOS COM CONTA BANCARIA
SELECT
    pg.id_pagamento,
    cb.descricao AS conta_bancaria,
    pg.valor_pago,
    pg.status_pagamento
FROM public.pagamento pg
JOIN public.conta_bancaria cb
    ON cb.id_conta_bancaria = pg.id_conta_bancaria
ORDER BY pg.id_pagamento;


-- SALDO DAS CONTAS
SELECT
    id_conta_bancaria,
    descricao,
    saldo_atual
FROM public.conta_bancaria
ORDER BY id_conta_bancaria;


-- TOTAL DE DESPESAS
SELECT
    COALESCE(SUM(valor), 0) AS total_despesas
FROM public.despesa;


-- TOTAL DE PAGAMENTOS REALIZADOS
SELECT
    COALESCE(SUM(valor_pago), 0) AS total_pago
FROM public.pagamento
WHERE status_pagamento = 'realizado';


-- QUANTIDADE DE TITULOS POR STATUS
SELECT
    status,
    COUNT(*) AS quantidade
FROM public.titulo_pagar
GROUP BY status
ORDER BY status;