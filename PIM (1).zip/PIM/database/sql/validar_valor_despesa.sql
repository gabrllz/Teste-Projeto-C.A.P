
SELECT id_despesa, descricao, valor
FROM despesa
WHERE valor IS NULL OR valor <= 0;

-- A protecao so e criada se os registros antigos forem validos. O bloco pode
-- ser executado novamente sem tentar criar a mesma restricao duas vezes.
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM despesa WHERE valor IS NULL OR valor <= 0
    ) THEN
        RAISE EXCEPTION 'Corrija primeiro as despesas com valor nulo, zero ou negativo.';
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'despesa_valor_positivo'
          AND conrelid = 'despesa'::regclass
    ) THEN
        ALTER TABLE despesa
        ADD CONSTRAINT despesa_valor_positivo
        CHECK (valor IS NOT NULL AND valor > 0);
    END IF;
END;
$$;
