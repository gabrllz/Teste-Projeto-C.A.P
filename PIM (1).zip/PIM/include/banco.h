#ifndef BANCO_H
#define BANCO_H
#include <libpq-fe.h>
PGconn *banco_conectar(void);
void banco_desconectar(PGconn *conexao);
#endif
