#ifndef CONTA_BANCARIA_H
#define CONTA_BANCARIA_H

#include <libpq-fe.h>

typedef struct {
    int id_conta_bancaria;
    char descricao[80];
    char saldo_atual[32];
    int ativo;
} ContaBancaria;

void conta_bancaria_menu(PGconn *conexao);

#endif
