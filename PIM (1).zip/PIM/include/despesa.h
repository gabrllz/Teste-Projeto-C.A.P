#ifndef DESPESA_H
#define DESPESA_H

#include <libpq-fe.h>

typedef struct {
    int id_despesa;
    int id_fornecedor;       /* 0 quando a despesa nao tiver fornecedor */
    char descricao[120];
    char tipo_despesa[16];   /* fixa ou variavel */
    char data_competencia[11]; /* formato AAAA-MM-DD */
    char valor[32];          /* o PostgreSQL converte o texto para numeric */
} Despesa;

void despesa_menu(PGconn *conexao);

#endif
