#ifndef PAGAMENTO_H
#define PAGAMENTO_H

#include <libpq-fe.h>

typedef struct {
    int id_pagamento;
    int id_parcela_pagar;
    int id_forma_pagamento;
    int id_conta_bancaria;
    char valor_pago[32];
    char motivo_cancelamento[160];
} Pagamento;

void pagamento_menu(PGconn *conexao);

#endif



