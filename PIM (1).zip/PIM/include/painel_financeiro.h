#ifndef PAINEL_FINANCEIRO_H
#define PAINEL_FINANCEIRO_H

#include <libpq-fe.h>

typedef struct {
    char saldo_bancario[40];
    char titulos_abertos[20];
    char parcelas_abertas[20];
    char total_pendente[40];
    char total_vencido[40];
    char total_ate_30_dias[40];
    char total_31_a_60_dias[40];
    char total_61_a_90_dias[40];
    int saldo_cobre_ate_30_dias;
} PainelFinanceiro;

void painel_financeiro_mostrar(PGconn *conexao);

#endif
