#ifndef PARCELA_PAGAR_H
#define PARCELA_PAGAR_H

#include <libpq-fe.h>

typedef struct {
    int id_parcela_pagar;
    int id_titulo_pagar;
    int numero_parcela;
    char vencimento[11];
    char valor[32];
    char status[40];
} ParcelaPagar;

void parcela_pagar_menu(PGconn *conexao);

#endif
