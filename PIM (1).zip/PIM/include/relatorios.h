#ifndef RELATORIOS_H
#define RELATORIOS_H

#include <libpq-fe.h>

void relatorios_menu(PGconn *conexao);

#endif
