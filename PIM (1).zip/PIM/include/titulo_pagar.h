#ifndef TITULO_PAGAR_H
#define TITULO_PAGAR_H

#include <libpq-fe.h>

typedef struct {
    int id_titulo_pagar;
    int id_fornecedor;
    int id_pedido_compra; /* 0 quando o titulo nao veio de pedido de compra */
    int id_despesa;       /* 0 quando o titulo nao veio de despesa */
    char data_emissao[11];
    char valor_total[32];
    char status[40];
} TituloPagar;

void titulo_pagar_menu(PGconn *conexao);

#endif
