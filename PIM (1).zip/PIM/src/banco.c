#include <stdio.h>
#include "banco.h"

/*
 * Este arquivo cuida da conexao com o PostgreSQL. PGconn representa essa
 * conexao. Se ela falhar, a funcao devolve NULL e o programa nao abre os menus.
 */
/* Abre a conexao usada por todos os modulos. O texto passado a PQconnectdb
 * informa onde esta o servidor e em qual banco e usuario entrar. */
PGconn *banco_conectar(void) {
    /* PQconnectdb recebe endereco, porta, banco e usuario do PostgreSQL. */
    PGconn *conexao = PQconnectdb(
        "host=127.0.0.1 "
        "port=5432 "
        "dbname=torra_db "
        "user=postgres "
        "password=123456"
    );

    /* PQstatus verifica se a conexao foi aberta. Em caso de falha,
     * PQerrorMessage explica o motivo, PQfinish libera a tentativa e NULL
     * informa ao programa que nao deve abrir os menus. */
    if (PQstatus(conexao) != CONNECTION_OK) {
        fprintf(stderr, "Erro ao conectar ao PostgreSQL:\n%s", PQerrorMessage(conexao));
        PQfinish(conexao);
        return NULL;
    }

    printf("Conectado ao banco %s como %s.\n", PQdb(conexao), PQuser(conexao));
    return conexao;
}

/* Fecha a conexao quando o programa termina; PQfinish libera o PGconn. */
void banco_desconectar(PGconn *conexao) {
    if (conexao != NULL) {
        PQfinish(conexao);
    }
}
