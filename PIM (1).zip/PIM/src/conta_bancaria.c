#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "conta_bancaria.h"

/*
 * O menu financeiro consulta e ajusta o saldo da conta principal cadastrada
 * em conta_bancaria. Os pagamentos tambem atualizam esse saldo no mesmo
 * momento em que sao gravados, para que o valor exibido reflita as baixas.
 */
static int ler_linha(const char *mensagem, char *destino, size_t tamanho) {
    printf("%s", mensagem);
    if (fgets(destino, (int)tamanho, stdin) == NULL) return 0;
    size_t tamanho_lido = strlen(destino);
    if (tamanho_lido > 0 && destino[tamanho_lido - 1] == '\n') {
        destino[tamanho_lido - 1] = '\0';
    }
    return 1;
}

/* Procura a conta principal somente entre as contas ativas. O SELECT traz
 * identificador, descricao e saldo para exibir os dados encontrados. */
static void consultar_saldo(PGconn *conexao) {
    PGresult *resultado = PQexec(conexao,
        "SELECT id_conta_bancaria, descricao, saldo_atual "
        "FROM conta_bancaria WHERE descricao = 'Conta principal' AND ativo = true");
    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        fprintf(stderr, "Erro ao consultar a conta:\n%s", PQresultErrorMessage(resultado));
        PQclear(resultado);
        return;
    }
    if (PQntuples(resultado) == 0) {
        puts("Conta principal nao encontrada ou inativa.");
        PQclear(resultado);
        return;
    }

    ContaBancaria conta = {0};
    conta.id_conta_bancaria = atoi(PQgetvalue(resultado, 0, 0));
    snprintf(conta.descricao, sizeof conta.descricao, "%s", PQgetvalue(resultado, 0, 1));
    snprintf(conta.saldo_atual, sizeof conta.saldo_atual, "%s", PQgetvalue(resultado, 0, 2));
    printf("Conta: %s (ID %d)\nSaldo disponivel: R$ %s\n",
           conta.descricao, conta.id_conta_bancaria, conta.saldo_atual);
    PQclear(resultado);
}

/* Esta funcao usa o mesmo formulario para entrada e retirada. O argumento
 * adicionar escolhe qual UPDATE sera enviado; cada UPDATE altera o saldo
 * somente se a conta estiver ativa e o valor for positivo. Na retirada, o
 * proprio WHERE tambem exige saldo suficiente. */
static void alterar_saldo(PGconn *conexao, int adicionar) {
    char valor[32];
    if (!ler_linha(adicionar ? "Valor a adicionar: R$ " : "Valor a retirar: R$ ",
                   valor, sizeof valor) || valor[0] == '\0') {
        puts("Informe um valor.");
        return;
    }

    const char *parametros[] = {valor};
const char *sql_adicionar =
        "UPDATE conta_bancaria SET saldo_atual = saldo_atual + $1::numeric "
        "WHERE descricao = 'Conta principal' AND ativo = true AND $1::numeric > 0 "
        "RETURNING saldo_atual";
    const char *sql_retirar =
        "UPDATE conta_bancaria SET saldo_atual = saldo_atual - $1::numeric "
        "WHERE descricao = 'Conta principal' AND ativo = true "
        "AND $1::numeric > 0 AND saldo_atual >= $1::numeric "
        "RETURNING saldo_atual";

    /* PQexecParams recebe o valor separado do SQL. RETURNING devolve o novo
     * saldo se o WHERE permitir a alteracao; sem linha retornada, a conta
     * nao existe/esta inativa, o valor e invalido ou nao ha saldo suficiente. */
    PGresult *resultado = PQexecParams(conexao,
        adicionar ? sql_adicionar : sql_retirar,
        1, NULL, parametros, NULL, NULL, 0);
    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        fprintf(stderr, "Valor invalido ou erro ao atualizar o saldo:\n%s",
                PQresultErrorMessage(resultado));
    } else if (PQntuples(resultado) == 0) {
        puts(adicionar
            ? "Nao foi possivel adicionar saldo. Verifique a conta e informe um valor positivo."
            : "Retirada nao realizada: saldo insuficiente ou valor invalido.");
    } else {
        printf("Saldo atualizado. Novo saldo: R$ %s\n", PQgetvalue(resultado, 0, 0));
    }
    PQclear(resultado);
}

void conta_bancaria_menu(PGconn *conexao) {
    char entrada[32];
    int opcao = -1;
    do {
        puts("\n==================================================");
        puts("  CONTA BANCARIA");
        puts("==================================================");
        puts("1. Consultar saldo\n2. Adicionar saldo\n3. Retirar saldo\n0. Voltar");
        printf("Escolha uma opcao: ");
        if (fgets(entrada, sizeof entrada, stdin) == NULL) return;
        if (sscanf(entrada, "%d", &opcao) != 1) opcao = -1;
        switch (opcao) {
            case 1: consultar_saldo(conexao); break;
            case 2: alterar_saldo(conexao, 1); break;
            case 3: alterar_saldo(conexao, 0); break;
            case 0: break;
            default: puts("Opcao invalida."); break;
        }
    } while (opcao != 0);
}
