#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include "despesa.h"

/*
 * Aqui sao cadastradas e consultadas despesas, como aluguel ou energia.
 * Uma despesa pode estar ligada a um fornecedor. O titulo e as parcelas
 * ligados a ela representam a conta a pagar e seus vencimentos.
 */
static int ler_linha(const char *mensagem, char *destino, size_t tamanho) {
    printf("%s", mensagem);
    if (fgets(destino, (int)tamanho, stdin) == NULL) {
        return 0;
    }

    size_t tamanho_lido = strlen(destino);
    if (tamanho_lido > 0 && destino[tamanho_lido - 1] == '\n') {
        destino[--tamanho_lido] = '\0';
        if (tamanho_lido > 0 && destino[tamanho_lido - 1] == '\r') {
            destino[--tamanho_lido] = '\0';
        }
    } else {
        int caractere;
        while ((caractere = getchar()) != '\n' && caractere != EOF) {
        }
    }
    return 1;
}

/* A data precisa ter o formato AAAA-MM-DD e corresponder a um dia real.
 * A funcao separa ano, mes e dia, verifica quantos dias aquele mes tem e
 * considera 29 de fevereiro nos anos bissextos. */
static int data_calendario_valida(const char *data) {
    if (strlen(data) != 10 || data[4] != '-' || data[7] != '-') return 0;
    for (int i = 0; i < 10; i++) {
        if (i != 4 && i != 7 && (data[i] < '0' || data[i] > '9')) return 0;
    }
    int ano = (data[0] - '0') * 1000 + (data[1] - '0') * 100 +
              (data[2] - '0') * 10 + (data[3] - '0');
    int mes = (data[5] - '0') * 10 + (data[6] - '0');
    int dia = (data[8] - '0') * 10 + (data[9] - '0');
    if (ano == 0 || mes < 1 || mes > 12) return 0;
    int dias_no_mes[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (mes == 2 && (ano % 400 == 0 || (ano % 4 == 0 && ano % 100 != 0))) {
        dias_no_mes[1] = 29;
    }
    return dia >= 1 && dia <= dias_no_mes[mes - 1];
}

/* strtod converte o texto digitado em numero. Depois desta conversao,
 * a funcao rejeita texto vazio, letras sobrando, valores fora da faixa aceita
 * e qualquer valor que seja zero ou negativo. */
static int valor_positivo_valido(const char *texto) {
    char *fim;
    errno = 0;
    double valor = strtod(texto, &fim);
    while (isspace((unsigned char)*fim)) fim++;
    return fim != texto && *fim == '\0' && errno != ERANGE &&
           isfinite(valor) && valor > 0;
}

/* Pede os dados da nova despesa e valida os campos antes de gravar.
 * O fornecedor e opcional: o numero 0 vira texto vazio e NULLIF transforma
 * esse texto em NULL no banco, indicando que nao foi informado fornecedor. */
static void cadastrar_despesa(PGconn *conexao) {
    Despesa despesa = {0};
    char id_fornecedor_texto[16];
    char entrada_id[16];

    puts("\n--- Nova despesa ---");
    if (!ler_linha("ID do fornecedor (0 se nao houver): ", entrada_id, sizeof entrada_id)) {
        puts("Entrada interrompida.");
        return;
    }
    if (entrada_id[0] != '\0' &&
        (sscanf(entrada_id, "%d", &despesa.id_fornecedor) != 1 || despesa.id_fornecedor < 0)) {
        puts("Informe um ID numerico valido ou 0.");
        return;
    }

    if (!ler_linha("Descricao: ", despesa.descricao, sizeof despesa.descricao) ||
        !ler_linha("Tipo (fixa ou variavel): ", despesa.tipo_despesa, sizeof despesa.tipo_despesa) ||
        !ler_linha("Data de competencia (AAAA-MM-DD): ", despesa.data_competencia, sizeof despesa.data_competencia) ||
        !ler_linha("Valor (use ponto decimal, ex.: 125.50): ", despesa.valor, sizeof despesa.valor)) {
        puts("Entrada interrompida.");
        return;
    }

    if (despesa.descricao[0] == '\0' || despesa.data_competencia[0] == '\0' || despesa.valor[0] == '\0') {
        puts("Descricao, data e valor sao obrigatorios.");
        return;
    }
    if (!data_calendario_valida(despesa.data_competencia)) {
        puts("Data invalida. Confira dia e mes; use AAAA-MM-DD, por exemplo 2026-10-30.");
        return;
    }
    /* Despesa com valor zero ou negativo nao deve ser cadastrada. */
    if (!valor_positivo_valido(despesa.valor)) {
        puts("O valor deve ser numerico, maior que zero e usar ponto decimal (ex.: 125.50).");
        return;
    }
    if (strcmp(despesa.tipo_despesa, "fixa") != 0 &&
        strcmp(despesa.tipo_despesa, "variavel") != 0) {
        puts("O tipo deve ser exatamente 'fixa' ou 'variavel'.");
        return;
    }

    if (despesa.id_fornecedor == 0) {
        id_fornecedor_texto[0] = '\0';
    } else {
        snprintf(id_fornecedor_texto, sizeof id_fornecedor_texto, "%d", despesa.id_fornecedor);
    }

    const char *parametros[] = {
        id_fornecedor_texto,
        despesa.descricao,
        despesa.tipo_despesa,
        despesa.data_competencia,
        despesa.valor
    };

    /* INSERT cria a despesa. $1 a $5 recebem os valores separados do SQL;
       NULLIF converte o texto vazio do fornecedor em NULL. RETURNING devolve
       o ID que o banco acabou de gerar. */
    PGresult *resultado = PQexecParams(
        conexao,
        "INSERT INTO despesa (id_fornecedor, descricao, tipo_despesa, data_competencia, valor) "
        "VALUES (NULLIF($1, '')::integer, $2, $3, $4::date, $5::numeric) "
        "RETURNING id_despesa",
        5,
        NULL,
        parametros,
        NULL,
        NULL,
        0
    );

    if (PQresultStatus(resultado) == PGRES_TUPLES_OK) {
        despesa.id_despesa = atoi(PQgetvalue(resultado, 0, 0));
        printf("Despesa cadastrada. ID: %d\n", despesa.id_despesa);
    } else {
        fprintf(stderr, "Nao foi possivel cadastrar a despesa:\n%s", PQresultErrorMessage(resultado));
    }
    PQclear(resultado);
}

/* A situacao da despesa e calculada olhando seus titulos e pagamentos.
 * Se tudo foi pago, aparece paga; se uma parcela venceu e ainda tem saldo,
 * aparece vencida. Pagamentos cancelados nao entram nessa conta. */
/* O CASE calcula uma situacao a partir dos titulos e pagamentos ligados:
     * sem titulo, paga, vencida, parcialmente paga ou pendente. A ordem das
     * condicoes importa: primeiro trata ausencia de titulo e quitacao, depois
     * atraso e pagamento parcial. O fornecedor e opcional, por isso LEFT JOIN. */
static void listar_despesas(PGconn *conexao) {
    PGresult *resultado = PQexec(
        conexao,
        "SELECT d.id_despesa, COALESCE(f.razao_social, '(sem fornecedor)'), "
        "d.descricao, d.tipo_despesa, to_char(d.data_competencia, 'YYYY-MM-DD'), d.valor, "
        "CASE "
        "WHEN NOT EXISTS (SELECT 1 FROM titulo_pagar t "
        "WHERE t.id_despesa = d.id_despesa) THEN 'sem titulo' "
        "WHEN NOT EXISTS (SELECT 1 FROM titulo_pagar t "
        "WHERE t.id_despesa = d.id_despesa AND t.valor_total > "
        "COALESCE((SELECT SUM(pg.valor_pago) FROM parcela_pagar p "
        "JOIN pagamento pg ON pg.id_parcela_pagar = p.id_parcela_pagar "
        "WHERE p.id_titulo_pagar = t.id_titulo_pagar "
        "AND pg.status_pagamento = 'realizado'), 0)) THEN 'paga' "
        "WHEN EXISTS (SELECT 1 FROM titulo_pagar t "
        "JOIN parcela_pagar p ON p.id_titulo_pagar = t.id_titulo_pagar "
        "WHERE t.id_despesa = d.id_despesa "
        "AND p.vencimento < CURRENT_DATE AND p.valor > "
        "COALESCE((SELECT SUM(pg.valor_pago) FROM pagamento pg "
        "WHERE pg.id_parcela_pagar = p.id_parcela_pagar "
        "AND pg.status_pagamento = 'realizado'), 0)) THEN 'vencida' "
        "WHEN EXISTS (SELECT 1 FROM titulo_pagar t "
        "WHERE t.id_despesa = d.id_despesa AND "
        "COALESCE((SELECT SUM(pg.valor_pago) FROM parcela_pagar p "
        "JOIN pagamento pg ON pg.id_parcela_pagar = p.id_parcela_pagar "
        "WHERE p.id_titulo_pagar = t.id_titulo_pagar "
        "AND pg.status_pagamento = 'realizado'), 0) > 0) "
        "THEN 'parcialmente paga' "
        "ELSE 'pendente' END AS situacao "
        "FROM despesa d "
        "LEFT JOIN fornecedor f ON f.id_fornecedor = d.id_fornecedor "
        "ORDER BY d.id_despesa"
    );

    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        fprintf(stderr, "Nao foi possivel consultar as despesas:\n%s", PQresultErrorMessage(resultado));
        PQclear(resultado);
        return;
    }
    if (PQntuples(resultado) == 0) {
        puts("Ainda nao ha despesas cadastradas.");
        PQclear(resultado);
        return;
    }

    puts("\nID | Fornecedor | Descricao | Tipo | Competencia | Valor | Situacao");
    puts("--------------------------------------------------------------------------------");
    for (int linha = 0; linha < PQntuples(resultado); linha++) {
        printf("%s | %s | %s | %s | %s | %s | %s\n",
               PQgetvalue(resultado, linha, 0),
               PQgetvalue(resultado, linha, 1),
               PQgetvalue(resultado, linha, 2),
               PQgetvalue(resultado, linha, 3),
               PQgetvalue(resultado, linha, 4),
               PQgetvalue(resultado, linha, 5),
               PQgetvalue(resultado, linha, 6));
    }
    PQclear(resultado);
}

/* Atualiza os dados da despesa identificada pelo ID. Os valores enviados
 * ficam separados do texto SQL; RETURNING permite saber se alguma linha foi
 * encontrada e, assim, avisar quando o ID informado nao existe. */
static void alterar_despesa(PGconn *conexao) {
    Despesa despesa = {0};
    char entrada[32];
    char id_fornecedor_texto[16];

    if (!ler_linha("ID da despesa que deseja alterar: ", entrada, sizeof entrada) ||
        sscanf(entrada, "%d", &despesa.id_despesa) != 1 || despesa.id_despesa <= 0) {
        puts("ID de despesa invalido.");
        return;
    }
    if (!ler_linha("Novo ID do fornecedor (0 se nao houver): ", entrada, sizeof entrada)) return;
    if (entrada[0] != '\0' &&
        (sscanf(entrada, "%d", &despesa.id_fornecedor) != 1 || despesa.id_fornecedor < 0)) {
        puts("Informe um ID numerico valido ou 0.");
        return;
    }
    if (!ler_linha("Nova descricao: ", despesa.descricao, sizeof despesa.descricao) ||
        !ler_linha("Novo tipo (fixa ou variavel): ", despesa.tipo_despesa, sizeof despesa.tipo_despesa) ||
        !ler_linha("Nova data de competencia (AAAA-MM-DD): ", despesa.data_competencia, sizeof despesa.data_competencia) ||
        !ler_linha("Novo valor (use ponto decimal): ", despesa.valor, sizeof despesa.valor)) {
        puts("Entrada interrompida.");
        return;
    }
    if (despesa.descricao[0] == '\0' || despesa.data_competencia[0] == '\0' ||
        despesa.valor[0] == '\0' ||
        (strcmp(despesa.tipo_despesa, "fixa") != 0 &&
         strcmp(despesa.tipo_despesa, "variavel") != 0)) {
        puts("Dados obrigatorios invalidos. Tipo deve ser fixa ou variavel.");
        return;
    }
      if (!data_calendario_valida(despesa.data_competencia)) {
          puts("Data invalida. Confira dia e mes; use AAAA-MM-DD, por exemplo 2026-10-30.");
          return;
      }
    if (!valor_positivo_valido(despesa.valor)) {
        puts("O valor deve ser numerico, maior que zero e usar ponto decimal (ex.: 125.50).");
        return;
    }

    if (despesa.id_fornecedor == 0) id_fornecedor_texto[0] = '\0';
    else snprintf(id_fornecedor_texto, sizeof id_fornecedor_texto, "%d", despesa.id_fornecedor);
    snprintf(entrada, sizeof entrada, "%d", despesa.id_despesa);

    const char *parametros[] = {
        id_fornecedor_texto, despesa.descricao, despesa.tipo_despesa,
        despesa.data_competencia, despesa.valor, entrada
    };
    PGresult *resultado = PQexecParams(
        conexao,
        "UPDATE despesa SET id_fornecedor = NULLIF($1, '')::integer, "
        "descricao = $2, tipo_despesa = $3, data_competencia = $4::date, "
        "valor = $5::numeric WHERE id_despesa = $6::integer "
        "RETURNING id_despesa",
        6, NULL, parametros, NULL, NULL, 0);

    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        fprintf(stderr, "Nao foi possivel alterar a despesa:\n%s", PQresultErrorMessage(resultado));
    } else if (PQntuples(resultado) == 0) {
        puts("Despesa nao encontrada.");
    } else {
        puts("Despesa alterada com sucesso.");
    }
    PQclear(resultado);
}

/* Pede confirmacao antes de apagar. O DELETE usa RETURNING para confirmar
 * se encontrou a despesa; se um titulo ainda apontar para ela, a chave
 * estrangeira impede a exclusao e o PostgreSQL informa o motivo. */
static void excluir_despesa(PGconn *conexao) {
    char entrada[32];
    char confirmacao[8];
    int id_despesa;

    if (!ler_linha("ID da despesa que deseja excluir: ", entrada, sizeof entrada) ||
        sscanf(entrada, "%d", &id_despesa) != 1 || id_despesa <= 0) {
        puts("ID de despesa invalido.");
        return;
    }
    if (!ler_linha("Confirma a exclusao? (s/n): ", confirmacao, sizeof confirmacao) ||
        (confirmacao[0] != 's' && confirmacao[0] != 'S')) {
        puts("Exclusao cancelada.");
        return;
    }

    snprintf(entrada, sizeof entrada, "%d", id_despesa);
    const char *parametros[] = {entrada};
    PGresult *resultado = PQexecParams(
        conexao,
        "DELETE FROM despesa WHERE id_despesa = $1::integer RETURNING id_despesa",
        1, NULL, parametros, NULL, NULL, 0);
    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        fprintf(stderr, "Nao foi possivel excluir. A despesa pode estar ligada a um titulo:\n%s",
                PQresultErrorMessage(resultado));
    } else if (PQntuples(resultado) == 0) {
        puts("Despesa nao encontrada.");
    } else {
        puts("Despesa excluida com sucesso.");
    }
    PQclear(resultado);
}
void despesa_menu(PGconn *conexao) {
    char entrada[32];
    int opcao = -1;

    do {
        puts("\n==================================================");
        puts("  DESPESAS");
        puts("==================================================");
        puts("1. Cadastrar despesa\n2. Listar despesas\n3. Alterar despesa\n4. Excluir despesa\n0. Voltar");
        printf("Escolha uma opcao: ");

        if (fgets(entrada, sizeof entrada, stdin) == NULL) {
            return;
        }
        if (sscanf(entrada, "%d", &opcao) != 1) {
            opcao = -1;
        }

        switch (opcao) {
            case 1: cadastrar_despesa(conexao); break;
            case 2: listar_despesas(conexao); break;
            case 3: alterar_despesa(conexao); break;
            case 4: excluir_despesa(conexao); break;
            case 0: break;
            default: puts("Opcao invalida."); break;
        }
    } while (opcao != 0);
}



