#include <stdio.h>
#ifdef _WIN32
#include <windows.h>
#endif
#include "banco.h"
#include "conta_bancaria.h"
#include "despesa.h"
#include "titulo_pagar.h"
#include "parcela_pagar.h"
#include "pagamento.h"
#include "painel_financeiro.h"
#include "relatorios.h"

/* Arquivo principal: mostra o menu e encaminha cada escolha para o modulo certo.
 * Abre a conexao com o banco antes do menu e fecha quando o usuario sai. */
static void mostrar_menu(void) {
    puts("\n==================================================");
    puts("  TORRA TORRA | CONTAS A PAGAR");
    puts("==================================================");
    puts("1. Painel financeiro");
    puts("2. Despesas");
    puts("3. Titulos a pagar");
    puts("4. Parcelas a pagar");
    puts("5. Pagamentos");
    puts("6. Saldo bancario");
    puts("7. Relatorios");
    puts("0. Sair");
    printf("Escolha uma opcao: ");
}

/* Inicia o sistema. Se nao conseguir conectar ao banco, encerra; caso
 * consiga, repete o menu ate o usuario escolher 0 para sair. */
int main(void) {
#ifdef _WIN32
    SetConsoleCP(CP_UTF8);
    SetConsoleOutputCP(CP_UTF8);
#endif
    PGconn *conexao = banco_conectar();
    if (conexao == NULL) return 1;

    char entrada[32];
    int opcao = -1;
    do {
        mostrar_menu();
        if (fgets(entrada, sizeof entrada, stdin) == NULL) break;
        if (sscanf(entrada, "%d", &opcao) != 1) opcao = -1;

        /* Cada case encaminha a escolha ao modulo correspondente. Por
         * exemplo, a opcao 5 abre Pagamentos e a opcao 7 abre Relatorios. */
        switch (opcao) {
            case 1: painel_financeiro_mostrar(conexao); break;
            case 2: despesa_menu(conexao); break;
            case 3: titulo_pagar_menu(conexao); break;
            case 4: parcela_pagar_menu(conexao); break;
            case 5: pagamento_menu(conexao); break;
            case 6: conta_bancaria_menu(conexao); break;
            case 7: relatorios_menu(conexao); break;
            case 0: puts("Encerrando o sistema."); break;
            default: puts("Opcao invalida."); break;
        }
    } while (opcao != 0);

    banco_desconectar(conexao);
    return 0;
}
