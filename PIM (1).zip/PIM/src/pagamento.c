#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pagamento.h"

/*
 * pagamento.c contem as opcoes do menu Pagamentos:
 *   1. consultar parcelas que ainda tem saldo;
 *   2. registrar um pagamento;
 *   3. cancelar um pagamento e devolver o valor a conta;
 *   4. consultar o historico, inclusive os cancelamentos.
 *
 * As tabelas se relacionam assim:
 *   titulo_pagar -> parcela_pagar -> pagamento
 * Um titulo pode ter varias parcelas, e uma parcela pode receber pagamentos
 * em partes. A forma de pagamento e mantida por outro modulo; este arquivo
 * consulta as formas ativas para o usuario escolher.
 *
 * A libpq conecta o C ao PostgreSQL:
 *   PGconn representa a conexao aberta;
 *   PGresult guarda o resultado de um comando;
 *   PQexec e PQexecParams enviam SQL ao banco;
 *   PQclear libera a memoria de um resultado depois do uso.
 */
/*
 * Mostra uma pergunta e guarda a resposta do usuario no vetor destino.
 * Retorna 1 se conseguiu ler ou 0 se a entrada foi interrompida.
 */
static int ler_linha(const char *mensagem, char *destino, size_t tamanho) {
    printf("%s", mensagem);
    /* fgets le a linha digitada, incluindo o ENTER no final. */
    if (fgets(destino, (int)tamanho, stdin) == NULL) return 0;
    size_t tamanho_lido = strlen(destino);
    if (tamanho_lido > 0 && destino[tamanho_lido - 1] == '\n') {
        /* Tira a quebra de linha para guardar so o texto digitado. */
        destino[--tamanho_lido] = '\0';
        if (tamanho_lido > 0 && destino[tamanho_lido - 1] == '\r') {
            /* No Windows, remove tambem o caractere que vem antes do \n. */
            destino[--tamanho_lido] = '\0';
        }
    } else {
        int caractere;
        while ((caractere = getchar()) != '\n' && caractere != EOF) {
        }
    }
    return 1;
}

/* Envia um comando de escrita ao banco, por exemplo INSERT ou UPDATE.
 * Os valores seguem separados do SQL. Retorna 1 no sucesso e 0 se falhar. */
static int executar_comando(PGconn *conexao, const char *sql,
                            int quantidade_parametros, const char *parametros[]) {
    /* PQexecParams envia o SQL e os valores separados. Assim, o texto
       digitado nao e colado diretamente dentro do comando SQL. */
    PGresult *resultado = PQexecParams(conexao, sql, quantidade_parametros,
                                        NULL, parametros, NULL, NULL, 0);
    if (PQresultStatus(resultado) != PGRES_COMMAND_OK) {
        fprintf(stderr, "Erro na operacao:\n%s", PQresultErrorMessage(resultado));
        PQclear(resultado);
        return 0;
    }
    PQclear(resultado);
    return 1;
}

/* ROLLBACK desfaz as alteracoes feitas desde o BEGIN, se algum passo falhar. */
static void cancelar_transacao(PGconn *conexao) {
    PGresult *resultado = PQexec(conexao, "ROLLBACK");
    PQclear(resultado);
}

/* Opcao 1: lista parcelas que ainda tem valor a pagar, da mais proxima do vencimento. */
static void consultar_parcelas_pendentes(PGconn *conexao) {
    /*
     * Explicando a consulta:
     * - LEFT JOIN mantem parcelas que ainda nao receberam pagamentos.
     * - SUM soma o que ja foi pago; COALESCE troca NULL por zero.
     * - O saldo e valor da parcela menos o total pago.
     * - CASE define se a parcela esta atrasada, parcialmente paga ou pendente.
     * - HAVING deixa somente parcelas cujo total pago ainda e menor que o valor.
     */
    /* LEFT JOIN inclui parcelas sem pagamento; a condicao no JOIN deixa
     * fora pagamentos cancelados. SUM soma o que ja foi pago, COALESCE troca
     * ausencia por zero e o saldo e valor da parcela menos essa soma.
     * CASE classifica atraso ou pagamento parcial; HAVING remove quitadas. */
    const char *sql =
        "SELECT t.id_titulo_pagar, p.id_parcela_pagar, p.numero_parcela, "
        "to_char(p.vencimento, 'YYYY-MM-DD'), p.valor, "
        "COALESCE(SUM(pg.valor_pago), 0), "
        "p.valor - COALESCE(SUM(pg.valor_pago), 0), "
        "CASE WHEN p.vencimento < CURRENT_DATE THEN 'atrasada' "
        "WHEN COALESCE(SUM(pg.valor_pago), 0) > 0 THEN 'parcialmente paga' "
        "ELSE 'pendente' END "
        "FROM parcela_pagar p "
        "JOIN titulo_pagar t ON t.id_titulo_pagar = p.id_titulo_pagar "
        "LEFT JOIN pagamento pg ON pg.id_parcela_pagar = p.id_parcela_pagar AND pg.status_pagamento = 'realizado' "
        "GROUP BY t.id_titulo_pagar, p.id_parcela_pagar "
        "HAVING COALESCE(SUM(pg.valor_pago), 0) < p.valor "
        "ORDER BY p.vencimento";

    /* PQexec envia este SELECT ao banco. O resultado fica em PGresult. */
    PGresult *resultado = PQexec(conexao, sql);
    /* Em um SELECT bem-sucedido, o PostgreSQL devolve PGRES_TUPLES_OK. */
    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        fprintf(stderr, "Erro ao consultar parcelas:\n%s", PQresultErrorMessage(resultado));
        PQclear(resultado);
        return;
    }
    /* PQntuples informa quantas linhas vieram do banco. Se retornar zero,
       esta consulta nao encontrou registros para mostrar. */
    if (PQntuples(resultado) == 0) {
        puts("Nao ha parcelas pendentes ou atrasadas.");
        PQclear(resultado);
        return;
    }

    puts("\nTitulo | Parcela | N | Vencimento | Valor | Pago | Saldo | Situacao");
    puts("--------------------------------------------------------------------------");
    /* Percorre cada linha retornada; PQgetvalue le o valor de uma coluna. */
    for (int linha = 0; linha < PQntuples(resultado); linha++) {
        for (int coluna = 0; coluna < 8; coluna++) {
            printf("%s%s", PQgetvalue(resultado, linha, coluna),
                   coluna == 7 ? "\n" : " | ");
        }
    }
    PQclear(resultado);
}

/* Busca as formas de pagamento ativas cadastradas pelo outro modulo.
 * Retorna 1 quando encontra uma opcao para o usuario escolher. */
static int listar_formas_ativas(PGconn *conexao) {
    /* A tabela de formas pertence a outro modulo; este menu apenas consulta
       as opcoes ativas para registrar qual foi usada no pagamento. */
    PGresult *resultado = PQexec(conexao,
        "SELECT id_forma_pagamento, descricao FROM forma_pagamento "
        "WHERE ativo = true ORDER BY id_forma_pagamento");
    /* Em um SELECT bem-sucedido, o PostgreSQL devolve PGRES_TUPLES_OK. */
    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        fprintf(stderr, "Erro ao consultar formas de pagamento:\n%s", PQresultErrorMessage(resultado));
        PQclear(resultado);
        return 0;
    }
    /* PQntuples informa quantas linhas vieram do banco. Se retornar zero,
       esta consulta nao encontrou registros para mostrar. */
    if (PQntuples(resultado) == 0) {
        puts("Nao existem formas de pagamento ativas cadastradas.");
        PQclear(resultado);
        return 0;
    }
    puts("\nFormas de pagamento ativas:");
    /* Percorre cada linha retornada; PQgetvalue le o valor de uma coluna. */
    for (int linha = 0; linha < PQntuples(resultado); linha++) {
        printf("%s - %s\n", PQgetvalue(resultado, linha, 0),
               PQgetvalue(resultado, linha, 1));
    }
    PQclear(resultado);
    return 1;
}

/* Recalcula o status da parcela seguindo esta ordem:
 *   1. se o total pago cobre o valor, fica paga;
 *   2. se venceu e ainda ha saldo, fica atrasada;
 *   3. se ja houve pagamento, mas falta uma parte, fica parcialmente paga;
 *   4. se nao houve pagamento, fica pendente.
 * Pagamentos cancelados nao entram na soma. */
static int atualizar_status_parcela(PGconn *conexao, const char *id_parcela) {
    const char *parametros[] = {id_parcela};
    /* A consulta soma apenas pagamentos com status realizado. O CASE escolhe
       o novo texto para a coluna status da parcela. */
    const char *sql =
        "UPDATE parcela_pagar p SET status = CASE "
        "WHEN (SELECT COALESCE(SUM(valor_pago), 0) FROM pagamento "
        "WHERE id_parcela_pagar = p.id_parcela_pagar AND status_pagamento = 'realizado') >= p.valor THEN 'paga' "
        "WHEN p.vencimento < CURRENT_DATE THEN 'atrasada' "
        "WHEN (SELECT COALESCE(SUM(valor_pago), 0) FROM pagamento "
        "WHERE id_parcela_pagar = p.id_parcela_pagar AND status_pagamento = 'realizado') > 0 THEN 'parcialmente paga' "
        "ELSE 'pendente' END "
        "WHERE p.id_parcela_pagar = $1::integer";
    return executar_comando(conexao, sql, 1, parametros);
}

/* Recalcula o status geral do título depois de um pagamento ou estorno.
 * Só marca como pago se houver parcelas, todas estiverem quitadas e a soma
 * dos pagamentos realizados alcançar o valor total do título. */
static int atualizar_status_titulo(PGconn *conexao, const char *id_titulo) {
    const char *parametros[] = {id_titulo};
    const char *sql =
        "UPDATE titulo_pagar t SET status = CASE "
        "WHEN EXISTS ( "
        "    SELECT 1 FROM parcela_pagar p "
        "    WHERE p.id_titulo_pagar = t.id_titulo_pagar "
        ") AND NOT EXISTS ( "
        "    SELECT 1 FROM parcela_pagar p "
        "    WHERE p.id_titulo_pagar = t.id_titulo_pagar "
        "    AND p.valor > COALESCE(( "
        "        SELECT SUM(pg.valor_pago) FROM pagamento pg "
        "        WHERE pg.id_parcela_pagar = p.id_parcela_pagar "
        "        AND pg.status_pagamento = 'realizado' "
        "    ), 0) "
        ") AND COALESCE(( "
        "    SELECT SUM(pg.valor_pago) FROM parcela_pagar p "
        "    JOIN pagamento pg ON pg.id_parcela_pagar = p.id_parcela_pagar "
        "    WHERE p.id_titulo_pagar = t.id_titulo_pagar "
        "    AND pg.status_pagamento = 'realizado' "
        "), 0) >= t.valor_total THEN 'pago' "
        "WHEN EXISTS ( "
        "    SELECT 1 FROM parcela_pagar p "
        "    JOIN pagamento pg ON pg.id_parcela_pagar = p.id_parcela_pagar "
        "    WHERE p.id_titulo_pagar = t.id_titulo_pagar "
        "    AND pg.status_pagamento = 'realizado' "
        ") THEN 'parcialmente pago' "
        "ELSE 'pendente' END "
        "WHERE t.id_titulo_pagar = $1::integer";
    return executar_comando(conexao, sql, 1, parametros);
}

/*
 * Opcao 2: registra um pagamento para uma parcela.
 * Passos:
 *   1. receber o ID da parcela, a forma de pagamento e o valor;
 *   2. conferir se a forma existe e esta ativa;
 *   3. iniciar uma transacao e travar a conta e a parcela;
 *   4. conferir se o valor cabe no saldo da parcela e no saldo bancario;
 *   5. debitar a conta, gravar o pagamento e atualizar os status;
 *   6. confirmar tudo com COMMIT, ou desfazer com ROLLBACK se houver erro.
 */
static void registrar_pagamento(PGconn *conexao) {
    Pagamento pagamento = {0};
    char entrada[32];
    char id_parcela[16];
    char id_forma[16];
    char id_conta[16];

    puts("\n--- Registrar pagamento ---");
    if (!ler_linha("ID da parcela: ", entrada, sizeof entrada) ||
        sscanf(entrada, "%d", &pagamento.id_parcela_pagar) != 1 ||
        pagamento.id_parcela_pagar <= 0) {
        puts("ID de parcela invalido.");
        return;
    }
    snprintf(id_parcela, sizeof id_parcela, "%d", pagamento.id_parcela_pagar);

    /* Primeiro escolhe uma forma ativa e depois informa o valor que sera pago. */
    if (!listar_formas_ativas(conexao) ||
        !ler_linha("ID da forma de pagamento: ", entrada, sizeof entrada) ||
        sscanf(entrada, "%d", &pagamento.id_forma_pagamento) != 1 ||
        pagamento.id_forma_pagamento <= 0) {
        puts("Forma de pagamento invalida.");
        return;
    }
    if (!ler_linha("Valor pago (use ponto decimal, ex.: 125.50): ",
                   pagamento.valor_pago, sizeof pagamento.valor_pago) ||
        pagamento.valor_pago[0] == '\0') {
        puts("Valor invalido.");
        return;
    }
    snprintf(id_forma, sizeof id_forma, "%d", pagamento.id_forma_pagamento);

    /* Confere novamente se o ID escolhido existe e continua ativo no banco. */
    const char *parametros_forma[] = {id_forma};
    PGresult *forma = PQexecParams(conexao,
        "SELECT id_forma_pagamento FROM forma_pagamento "
        "WHERE id_forma_pagamento = $1::integer AND ativo = true",
        1, NULL, parametros_forma, NULL, NULL, 0);
    if (PQresultStatus(forma) != PGRES_TUPLES_OK || PQntuples(forma) == 0) {
        puts("Forma de pagamento nao encontrada ou inativa.");
        PQclear(forma);
        return;
    }
    PQclear(forma);

    /* BEGIN inicia uma transacao: as mudancas so ficam definitivas no COMMIT. */
    PGresult *inicio = PQexec(conexao, "BEGIN");
    if (PQresultStatus(inicio) != PGRES_COMMAND_OK) {
        fprintf(stderr, "Nao foi possivel iniciar a operacao:\n%s", PQresultErrorMessage(inicio));
        PQclear(inicio);
        return;
    }
    PQclear(inicio);

    /* FOR UPDATE segura a conta durante este pagamento. Assim, duas
       operacoes nao usam o mesmo saldo ao mesmo tempo. */
    PGresult *conta = PQexec(conexao,
        "SELECT id_conta_bancaria FROM conta_bancaria "
        "WHERE descricao = 'Conta principal' AND ativo = true FOR UPDATE");
    if (PQresultStatus(conta) != PGRES_TUPLES_OK || PQntuples(conta) == 0) {
        puts("Conta principal nao encontrada ou inativa.");
        PQclear(conta);
        cancelar_transacao(conexao);
        return;
    }
    pagamento.id_conta_bancaria = atoi(PQgetvalue(conta, 0, 0));
    PQclear(conta);
    snprintf(id_conta, sizeof id_conta, "%d", pagamento.id_conta_bancaria);

    /* Busca o titulo relacionado a parcela; o ID sera usado para atualizar
       a situacao do titulo depois do pagamento. */
    const char *parametros_parcela[] = {id_parcela};
    PGresult *parcela = PQexecParams(conexao,
        "SELECT id_titulo_pagar FROM parcela_pagar "
        "WHERE id_parcela_pagar = $1::integer FOR UPDATE",
        1, NULL, parametros_parcela, NULL, NULL, 0);
    if (PQresultStatus(parcela) != PGRES_TUPLES_OK || PQntuples(parcela) == 0) {
        puts("Parcela nao encontrada.");
        PQclear(parcela);
        cancelar_transacao(conexao);
        return;
    }
    char id_titulo[16];
    snprintf(id_titulo, sizeof id_titulo, "%s", PQgetvalue(parcela, 0, 0));
    PQclear(parcela);

    /* Antes de aceitar o pagamento, confere se as parcelas representam o
     * valor inteiro do título. Sem isso, todas poderiam ser quitadas e ainda
     * sobrar uma parte do título sem parcela correspondente. */
    const char *parametros_total[] = {id_titulo};
    PGresult *total_parcelas = PQexecParams(conexao,
        "SELECT t.valor_total = COALESCE(SUM(p.valor), 0) "
        "FROM titulo_pagar t LEFT JOIN parcela_pagar p "
        "ON p.id_titulo_pagar = t.id_titulo_pagar "
        "WHERE t.id_titulo_pagar = $1::integer "
        "GROUP BY t.id_titulo_pagar, t.valor_total",
        1, NULL, parametros_total, NULL, NULL, 0);
    if (PQresultStatus(total_parcelas) != PGRES_TUPLES_OK ||
        PQntuples(total_parcelas) == 0) {
        fprintf(stderr, "Nao foi possivel conferir o total das parcelas:\n%s",
                PQresultErrorMessage(total_parcelas));
        PQclear(total_parcelas);
        cancelar_transacao(conexao);
        return;
    }
    if (strcmp(PQgetvalue(total_parcelas, 0, 0), "t") != 0) {
        puts("A soma das parcelas precisa ser igual ao valor total do título antes do pagamento.");
        PQclear(total_parcelas);
        cancelar_transacao(conexao);
        return;
    }
    PQclear(total_parcelas);

    /* O SELECT compara o valor informado com o saldo da parcela. A subconsulta
     * calcula esse saldo somando apenas pagamentos realizados; o resultado
     * booleano sera verdadeiro somente para valor positivo dentro do limite. */
    const char *parametros_saldo_parcela[] = {id_parcela, pagamento.valor_pago};
    PGresult *saldo_parcela = PQexecParams(conexao,
        "SELECT $2::numeric > 0 AND $2::numeric <= "
        "(SELECT p.valor - COALESCE(SUM(pg.valor_pago), 0) "
        "FROM parcela_pagar p LEFT JOIN pagamento pg "
        "ON pg.id_parcela_pagar = p.id_parcela_pagar AND pg.status_pagamento = 'realizado' "
        "WHERE p.id_parcela_pagar = $1::integer GROUP BY p.valor)",
        2, NULL, parametros_saldo_parcela, NULL, NULL, 0);
    if (PQresultStatus(saldo_parcela) != PGRES_TUPLES_OK ||
        PQntuples(saldo_parcela) == 0 || strcmp(PQgetvalue(saldo_parcela, 0, 0), "t") != 0) {
        puts("O valor deve ser positivo e nao pode ultrapassar o saldo da parcela.");
        PQclear(saldo_parcela);
        cancelar_transacao(conexao);
        return;
    }
    PQclear(saldo_parcela);

    /* Retira o valor somente se a conta tiver saldo suficiente. RETURNING
       devolve o novo saldo quando a retirada acontece. */
    const char *parametros_debito[] = {id_conta, pagamento.valor_pago};
    PGresult *debito = PQexecParams(conexao,
        "UPDATE conta_bancaria SET saldo_atual = saldo_atual - $2::numeric "
        "WHERE id_conta_bancaria = $1::integer AND ativo = true "
        "AND $2::numeric > 0 AND saldo_atual >= $2::numeric "
        "RETURNING saldo_atual",
        2, NULL, parametros_debito, NULL, NULL, 0);
    if (PQresultStatus(debito) != PGRES_TUPLES_OK || PQntuples(debito) == 0) {
        puts("Saldo bancario insuficiente para esse pagamento.");
        PQclear(debito);
        cancelar_transacao(conexao);
        return;
    }
    PQclear(debito);

    /* Grava os dados do pagamento. O status usa o padrao realizado definido
       na tabela, e CURRENT_TIMESTAMP guarda a data e hora deste momento. */
    const char *parametros_pagamento[] = {
        id_parcela, id_forma, id_conta, pagamento.valor_pago
    };
    const char *sql_pagamento =
        "INSERT INTO pagamento "
        "(id_parcela_pagar, id_forma_pagamento, id_conta_bancaria, data_pagamento, valor_pago) "
        "VALUES ($1::integer, $2::integer, $3::integer, CURRENT_TIMESTAMP, $4::numeric)";
    if (!executar_comando(conexao, sql_pagamento, 4, parametros_pagamento) ||
        !atualizar_status_parcela(conexao, id_parcela) ||
        !atualizar_status_titulo(conexao, id_titulo)) {
        cancelar_transacao(conexao);
        return;
    }

    /* COMMIT confirma a operacao: saldo, pagamento e status ficam salvos juntos. */
    PGresult *confirmacao = PQexec(conexao, "COMMIT");
    if (PQresultStatus(confirmacao) == PGRES_COMMAND_OK) {
        puts("Pagamento registrado; saldo, parcela e titulo atualizados.");
    } else {
        fprintf(stderr, "Falha ao confirmar a operacao:\n%s", PQresultErrorMessage(confirmacao));
        cancelar_transacao(conexao);
    }
    PQclear(confirmacao);
}

/* Opcao 4: mostra os pagamentos mais recentes primeiro, inclusive os cancelados. */
static void consultar_historico_pagamentos(PGconn *conexao) {
    /* Os JOINs ligam pagamento a parcela, titulo e forma de pagamento.
       LEFT JOIN mantem a linha mesmo sem conta; COALESCE mostra um traco. */
    const char *sql =
        "SELECT pg.id_pagamento, t.id_titulo_pagar, p.id_parcela_pagar, "
        "f.descricao, COALESCE(c.descricao, '-'), "
        "to_char(pg.data_pagamento, 'YYYY-MM-DD HH24:MI:SS'), pg.valor_pago, "
        "pg.status_pagamento, COALESCE(pg.motivo_cancelamento, '-') "
        "FROM pagamento pg "
        "JOIN parcela_pagar p ON p.id_parcela_pagar = pg.id_parcela_pagar "
        "JOIN titulo_pagar t ON t.id_titulo_pagar = p.id_titulo_pagar "
        "JOIN forma_pagamento f ON f.id_forma_pagamento = pg.id_forma_pagamento "
        "LEFT JOIN conta_bancaria c ON c.id_conta_bancaria = pg.id_conta_bancaria "
        "ORDER BY pg.data_pagamento DESC, pg.id_pagamento DESC";

    /* PQexec envia este SELECT ao banco. O resultado fica em PGresult. */
    PGresult *resultado = PQexec(conexao, sql);
    /* Em um SELECT bem-sucedido, o PostgreSQL devolve PGRES_TUPLES_OK. */
    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        fprintf(stderr, "Erro ao consultar o historico de pagamentos:\n%s",
                PQresultErrorMessage(resultado));
        PQclear(resultado);
        return;
    }
    /* PQntuples informa quantas linhas vieram do banco. Se retornar zero,
       esta consulta nao encontrou registros para mostrar. */
    if (PQntuples(resultado) == 0) {
        puts("Ainda nao ha pagamentos registrados.");
        PQclear(resultado);
        return;
    }

    puts("\nID | Titulo | Parcela | Forma | Conta | Data | Valor | Status | Motivo");
    puts("-------------------------------------------------------------------------------------");
    /* Percorre cada linha retornada; PQgetvalue le o valor de uma coluna. */
    for (int linha = 0; linha < PQntuples(resultado); linha++) {
        for (int coluna = 0; coluna < 9; coluna++) {
            printf("%s%s", PQgetvalue(resultado, linha, coluna),
                   coluna == 8 ? "\n" : " | ");
        }
    }
    PQclear(resultado);
}
/*
 * Opcao 3: cancela um pagamento sem apagar seu historico.
 * Passos:
 *   1. pedir o ID e o motivo do cancelamento;
 *   2. procurar um pagamento ainda realizado;
 *   3. devolver o valor pago ao saldo da conta;
 *   4. marcar o pagamento como cancelado;
 *   5. recalcular os status da parcela e do titulo;
 *   6. confirmar tudo junto ou desfazer se algum passo falhar.
 */
static void cancelar_pagamento(PGconn *conexao) {
    Pagamento pagamento = {0};
    char entrada[32];
    char id_pagamento[16];
    char id_parcela[16];
    char id_conta[16];

    /* Pede o ID do pagamento e o motivo. Sem um motivo, o cancelamento para. */
    if (!ler_linha("ID do pagamento que deseja cancelar: ", entrada, sizeof entrada) ||
        sscanf(entrada, "%d", &pagamento.id_pagamento) != 1 || pagamento.id_pagamento <= 0) {
        puts("ID de pagamento invalido.");
        return;
    }
    if (!ler_linha("Motivo do cancelamento: ", pagamento.motivo_cancelamento,
                   sizeof pagamento.motivo_cancelamento) || pagamento.motivo_cancelamento[0] == '\0') {
        puts("O motivo do cancelamento e obrigatorio.");
        return;
    }
    snprintf(id_pagamento, sizeof id_pagamento, "%d", pagamento.id_pagamento);

    PGresult *inicio = PQexec(conexao, "BEGIN");
    if (PQresultStatus(inicio) != PGRES_COMMAND_OK) {
        fprintf(stderr, "Nao foi possivel iniciar o cancelamento:\n%s", PQresultErrorMessage(inicio));
        PQclear(inicio);
        return;
    }
    PQclear(inicio);

    /* Procura somente pagamentos realizados; um pagamento ja cancelado nao
       pode ser estornado outra vez. */
    const char *parametros_id[] = {id_pagamento};
    /* Localiza o pagamento ainda realizado e busca a conta, a parcela, o
     * valor e o titulo relacionado. FOR UPDATE bloqueia essa linha durante
     * o estorno para impedir que o mesmo pagamento seja cancelado duas vezes. */
    PGresult *registro = PQexecParams(conexao,
        "SELECT pg.id_conta_bancaria, pg.id_parcela_pagar, pg.valor_pago, p.id_titulo_pagar "
        "FROM pagamento pg JOIN parcela_pagar p ON p.id_parcela_pagar = pg.id_parcela_pagar "
        "WHERE pg.id_pagamento = $1::integer AND pg.status_pagamento = 'realizado' "
        "FOR UPDATE OF pg",
        1, NULL, parametros_id, NULL, NULL, 0);
    if (PQresultStatus(registro) != PGRES_TUPLES_OK || PQntuples(registro) == 0 ||
        PQgetisnull(registro, 0, 0)) {
        puts("Pagamento nao encontrado, ja cancelado ou sem conta associada.");
        PQclear(registro);
        cancelar_transacao(conexao);
        return;
    }

    pagamento.id_conta_bancaria = atoi(PQgetvalue(registro, 0, 0));
    pagamento.id_parcela_pagar = atoi(PQgetvalue(registro, 0, 1));
    char valor_pago[32];
    char id_titulo[16];
    snprintf(valor_pago, sizeof valor_pago, "%s", PQgetvalue(registro, 0, 2));
    snprintf(id_titulo, sizeof id_titulo, "%s", PQgetvalue(registro, 0, 3));
    PQclear(registro);

    snprintf(id_conta, sizeof id_conta, "%d", pagamento.id_conta_bancaria);
    snprintf(id_parcela, sizeof id_parcela, "%d", pagamento.id_parcela_pagar);
    /* O UPDATE soma ao saldo o mesmo valor que saiu no pagamento. Como esta
     * etapa faz parte da transacao, qualquer erro posterior tambem desfaz a
     * devolucao por meio de ROLLBACK. */
    const char *parametros_estorno[] = {id_conta, valor_pago};
    if (!executar_comando(conexao,
        "UPDATE conta_bancaria SET saldo_atual = saldo_atual + $2::numeric "
        "WHERE id_conta_bancaria = $1::integer",
        2, parametros_estorno)) {
        cancelar_transacao(conexao);
        return;
    }

    /* Guarda o motivo e muda o status. O registro continua no historico. */
    const char *parametros_cancelamento[] = {id_pagamento, pagamento.motivo_cancelamento};
    if (!executar_comando(conexao,
        "UPDATE pagamento SET status_pagamento = 'cancelado', motivo_cancelamento = $2 "
        "WHERE id_pagamento = $1::integer AND status_pagamento = 'realizado'",
        2, parametros_cancelamento) ||
        !atualizar_status_parcela(conexao, id_parcela) ||
        !atualizar_status_titulo(conexao, id_titulo)) {
        cancelar_transacao(conexao);
        return;
    }

    /* COMMIT confirma a operacao: saldo, pagamento e status ficam salvos juntos. */
    PGresult *confirmacao = PQexec(conexao, "COMMIT");
    if (PQresultStatus(confirmacao) == PGRES_COMMAND_OK) {
        puts("Pagamento cancelado; valor devolvido a conta e status recalculados.");
    } else {
        fprintf(stderr, "Falha ao confirmar cancelamento:\n%s", PQresultErrorMessage(confirmacao));
        cancelar_transacao(conexao);
    }
    PQclear(confirmacao);
}
/* Mantem o menu de pagamentos aberto ate o usuario escolher voltar.
 * Cada opcao chama a consulta ou operacao correspondente e compartilha a
 * mesma conexao ja aberta pelo programa principal. */
void pagamento_menu(PGconn *conexao) {
    char entrada[32];
    int opcao = -1;
    do {
        puts("\n==================================================");
        puts("  PAGAMENTOS");
        puts("==================================================");
        puts("1. Consultar parcelas pendentes\n2. Registrar pagamento\n3. Cancelar pagamento\n4. Consultar historico\n0. Voltar");
        printf("Escolha uma opcao: ");
        if (fgets(entrada, sizeof entrada, stdin) == NULL) return;
        if (sscanf(entrada, "%d", &opcao) != 1) opcao = -1;
        switch (opcao) {
            case 1: consultar_parcelas_pendentes(conexao); break;
            case 2: registrar_pagamento(conexao); break;
            case 3: cancelar_pagamento(conexao); break;
            case 4: consultar_historico_pagamentos(conexao); break;
            case 0: break;
            default: puts("Opcao invalida."); break;
        }
    } while (opcao != 0);
}





