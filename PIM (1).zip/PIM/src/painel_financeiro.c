#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "painel_financeiro.h"

/*
 * O painel resume quanto ha no banco, quanto falta pagar e quais parcelas
 * estao vencidas ou vencerao nos proximos 30, 60 ou 90 dias. Para calcular o
 * que falta, desconta da parcela os pagamentos realizados.
 */
/* Executa uma consulta de indicador, guarda a primeira coluna na estrutura
 * do painel e retorna 0 se o banco falhar ou nao encontrar uma linha. */
static int consultar_valor(PGconn *conexao, const char *sql,
                           char *destino, size_t tamanho) {
    PGresult *resultado = PQexec(conexao, sql);
    if (PQresultStatus(resultado) != PGRES_TUPLES_OK || PQntuples(resultado) == 0) {
        fprintf(stderr, "Nao foi possivel consultar o painel financeiro:\n%s",
                PQresultErrorMessage(resultado));
        PQclear(resultado);
        return 0;
    }

    snprintf(destino, tamanho, "%s", PQgetvalue(resultado, 0, 0));
    PQclear(resultado);
    return 1;
}

/* Busca os indicadores que aparecem no painel. Para cada parcela, calcula
 * o restante subtraindo do valor original apenas pagamentos realizados;
 * pagamentos cancelados nao reduzem a divida. CURRENT_DATE define as faixas:
 * vencidas, hoje a 30 dias, 31 a 60 dias e 61 a 90 dias. Ao final, compara
 * o saldo da conta principal com os vencimentos dos proximos 30 dias. */
static int consultar_resumo(PGconn *conexao, PainelFinanceiro *painel) {
    const char *sql_saldo =
        "SELECT COALESCE((SELECT saldo_atual FROM conta_bancaria "
        "WHERE descricao = 'Conta principal' AND ativo = true), 0)::text";
    const char *sql_titulos =
        "SELECT COUNT(*)::text FROM titulo_pagar WHERE status <> 'pago'";
    const char *sql_parcelas =
        "SELECT COUNT(*)::text FROM parcela_pagar p "
        "WHERE p.valor > COALESCE((SELECT SUM(pg.valor_pago) FROM pagamento pg "
        "WHERE pg.id_parcela_pagar = p.id_parcela_pagar "
        "AND pg.status_pagamento = 'realizado'), 0)";
    const char *sql_total_pendente =
        "SELECT COALESCE(SUM(p.valor - COALESCE((SELECT SUM(pg.valor_pago) "
        "FROM pagamento pg WHERE pg.id_parcela_pagar = p.id_parcela_pagar "
        "AND pg.status_pagamento = 'realizado'), 0)), 0)::text "
        "FROM parcela_pagar p WHERE p.valor > COALESCE((SELECT SUM(pg.valor_pago) "
        "FROM pagamento pg WHERE pg.id_parcela_pagar = p.id_parcela_pagar "
        "AND pg.status_pagamento = 'realizado'), 0)";
    const char *sql_vencido =
        "SELECT COALESCE(SUM(p.valor - COALESCE((SELECT SUM(pg.valor_pago) "
        "FROM pagamento pg WHERE pg.id_parcela_pagar = p.id_parcela_pagar "
        "AND pg.status_pagamento = 'realizado'), 0)), 0)::text "
        "FROM parcela_pagar p WHERE p.vencimento < CURRENT_DATE "
        "AND p.valor > COALESCE((SELECT SUM(pg.valor_pago) FROM pagamento pg "
        "WHERE pg.id_parcela_pagar = p.id_parcela_pagar "
        "AND pg.status_pagamento = 'realizado'), 0)";
    const char *sql_ate_30 =
        "SELECT COALESCE(SUM(p.valor - COALESCE((SELECT SUM(pg.valor_pago) "
        "FROM pagamento pg WHERE pg.id_parcela_pagar = p.id_parcela_pagar "
        "AND pg.status_pagamento = 'realizado'), 0)), 0)::text "
        "FROM parcela_pagar p WHERE p.vencimento >= CURRENT_DATE "
        "AND p.vencimento <= CURRENT_DATE + 30 "
        "AND p.valor > COALESCE((SELECT SUM(pg.valor_pago) FROM pagamento pg "
        "WHERE pg.id_parcela_pagar = p.id_parcela_pagar "
        "AND pg.status_pagamento = 'realizado'), 0)";
    const char *sql_31_a_60 =
        "SELECT COALESCE(SUM(p.valor - COALESCE((SELECT SUM(pg.valor_pago) "
        "FROM pagamento pg WHERE pg.id_parcela_pagar = p.id_parcela_pagar "
        "AND pg.status_pagamento = 'realizado'), 0)), 0)::text "
        "FROM parcela_pagar p WHERE p.vencimento > CURRENT_DATE + 30 "
        "AND p.vencimento <= CURRENT_DATE + 60 "
        "AND p.valor > COALESCE((SELECT SUM(pg.valor_pago) FROM pagamento pg "
        "WHERE pg.id_parcela_pagar = p.id_parcela_pagar "
        "AND pg.status_pagamento = 'realizado'), 0)";
    const char *sql_61_a_90 =
        "SELECT COALESCE(SUM(p.valor - COALESCE((SELECT SUM(pg.valor_pago) "
        "FROM pagamento pg WHERE pg.id_parcela_pagar = p.id_parcela_pagar "
        "AND pg.status_pagamento = 'realizado'), 0)), 0)::text "
        "FROM parcela_pagar p WHERE p.vencimento > CURRENT_DATE + 60 "
        "AND p.vencimento <= CURRENT_DATE + 90 "
        "AND p.valor > COALESCE((SELECT SUM(pg.valor_pago) FROM pagamento pg "
        "WHERE pg.id_parcela_pagar = p.id_parcela_pagar "
        "AND pg.status_pagamento = 'realizado'), 0)";
    if (!consultar_valor(conexao, sql_saldo, painel->saldo_bancario,
                         sizeof painel->saldo_bancario) ||
        !consultar_valor(conexao, sql_titulos, painel->titulos_abertos,
                         sizeof painel->titulos_abertos) ||
        !consultar_valor(conexao, sql_parcelas, painel->parcelas_abertas,
                         sizeof painel->parcelas_abertas) ||
        !consultar_valor(conexao, sql_total_pendente, painel->total_pendente,
                         sizeof painel->total_pendente) ||
        !consultar_valor(conexao, sql_vencido, painel->total_vencido,
                         sizeof painel->total_vencido) ||
        !consultar_valor(conexao, sql_ate_30, painel->total_ate_30_dias,
                         sizeof painel->total_ate_30_dias) ||
        !consultar_valor(conexao, sql_31_a_60, painel->total_31_a_60_dias,
                         sizeof painel->total_31_a_60_dias) ||
        !consultar_valor(conexao, sql_61_a_90, painel->total_61_a_90_dias,
                         sizeof painel->total_61_a_90_dias)) {
        return 0;
    }

    /* Compara os dois valores que o painel ja consultou. */
    /* A comparacao retorna uma linha sempre: t se o saldo cobre a faixa,
     * f se nao cobre. Assim, o painel consegue exibir os dois cenarios. */
    const char *parametros[] = {
        painel->saldo_bancario,
        painel->total_ate_30_dias
    };
    PGresult *resultado = PQexecParams(
        conexao,
        "SELECT $1::numeric >= $2::numeric",
        2, NULL, parametros, NULL, NULL, 0);
    if (PQresultStatus(resultado) != PGRES_TUPLES_OK || PQntuples(resultado) == 0) {
        fprintf(stderr, "Nao foi possivel comparar o saldo com os vencimentos:\n%s",
                PQresultErrorMessage(resultado));
        PQclear(resultado);
        return 0;
    }
    painel->saldo_cobre_ate_30_dias = strcmp(PQgetvalue(resultado, 0, 0), "t") == 0;
    PQclear(resultado);
    return 1;
}

/* Lista titulos ainda nao pagos com fornecedor, emissao, valor e status.
 * JOIN relaciona o titulo ao fornecedor; ORDER BY organiza pela emissao. */
static void listar_titulos_abertos(PGconn *conexao) {
    const char *sql =
        "SELECT t.id_titulo_pagar, f.razao_social, "
        "to_char(t.data_emissao, 'YYYY-MM-DD'), t.valor_total, t.status "
        "FROM titulo_pagar t JOIN fornecedor f "
        "ON f.id_fornecedor = t.id_fornecedor "
        "WHERE t.status <> 'pago' "
        "ORDER BY t.data_emissao, t.id_titulo_pagar";

    PGresult *resultado = PQexec(conexao, sql);
    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        fprintf(stderr, "Nao foi possivel consultar os titulos em aberto:\n%s",
                PQresultErrorMessage(resultado));
        PQclear(resultado);
        return;
    }
    if (PQntuples(resultado) == 0) {
        puts("Nao ha titulos em aberto.");
        PQclear(resultado);
        return;
    }

    puts("\nTitulos em aberto");
    puts("ID | Fornecedor | Emissao | Valor total | Status");
    puts("----------------------------------------------------------");
    for (int linha = 0; linha < PQntuples(resultado); linha++) {
        for (int coluna = 0; coluna < 5; coluna++) {
            printf("%s%s", PQgetvalue(resultado, linha, coluna),
                   coluna == 4 ? "\n" : " | ");
        }
    }
    PQclear(resultado);
}

/* Lista ate dez parcelas com saldo dentro do periodo indicado por faixa.
 * LEFT JOIN mantem as que nao tiveram pagamento; SUM e COALESCE calculam o
 * total pago. HAVING remove quitadas, o parametro define a faixa de dias e
 * LIMIT restringe a lista ordenada pelos vencimentos mais proximos. */
static void listar_parcelas(PGconn *conexao, int faixa) {
    const char *sql =
        "SELECT t.id_titulo_pagar, f.razao_social, "
        "p.numero_parcela, to_char(p.vencimento, 'YYYY-MM-DD'), p.valor, "
        "COALESCE(SUM(pg.valor_pago), 0), "
        "p.valor - COALESCE(SUM(pg.valor_pago), 0) "
        "FROM parcela_pagar p "
        "JOIN titulo_pagar t ON t.id_titulo_pagar = p.id_titulo_pagar "
        "JOIN fornecedor f ON f.id_fornecedor = t.id_fornecedor "
        "LEFT JOIN pagamento pg ON pg.id_parcela_pagar = p.id_parcela_pagar "
        "AND pg.status_pagamento = 'realizado' "
        "GROUP BY t.id_titulo_pagar, f.razao_social, p.id_parcela_pagar "
        "HAVING p.valor - COALESCE(SUM(pg.valor_pago), 0) > 0 "
        "AND (($1::integer = 0 AND p.vencimento < CURRENT_DATE) "
        "OR ($1::integer = 1 AND p.vencimento >= CURRENT_DATE "
        "AND p.vencimento <= CURRENT_DATE + 30) "
        "OR ($1::integer = 2 AND p.vencimento > CURRENT_DATE + 30 "
        "AND p.vencimento <= CURRENT_DATE + 60) "
        "OR ($1::integer = 3 AND p.vencimento > CURRENT_DATE + 60 "
        "AND p.vencimento <= CURRENT_DATE + 90)) "
        "ORDER BY p.vencimento, t.id_titulo_pagar, p.numero_parcela "
        "LIMIT 10";
    char faixa_texto[2];
    snprintf(faixa_texto, sizeof faixa_texto, "%d", faixa);
    const char *parametros[] = {faixa_texto};
    PGresult *resultado = PQexecParams(conexao, sql, 1, NULL, parametros,
                                       NULL, NULL, 0);

    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        fprintf(stderr, "Nao foi possivel consultar as parcelas:\n%s",
                PQresultErrorMessage(resultado));
        PQclear(resultado);
        return;
    }
    if (PQntuples(resultado) == 0) {
        switch (faixa) {
            case 0: puts("Nao ha parcelas vencidas."); break;
            case 1: puts("Nao ha vencimentos ate 30 dias."); break;
            case 2: puts("Nao ha vencimentos entre 31 e 60 dias."); break;
            default: puts("Nao ha vencimentos entre 61 e 90 dias."); break;
        }
        PQclear(resultado);
        return;
    }

    switch (faixa) {
        case 0: puts("\nParcelas vencidas (ate 10 mais antigas)"); break;
        case 1: puts("\nVencimentos de hoje a 30 dias (ate 10 mais proximos)"); break;
        case 2: puts("\nVencimentos de 31 a 60 dias (ate 10 mais proximos)"); break;
        default: puts("\nVencimentos de 61 a 90 dias (ate 10 mais proximos)"); break;
    }
    puts("Titulo | Fornecedor | Parcela | Vencimento | Valor | Pago | Restante");
    puts("--------------------------------------------------------------------------");
    for (int linha = 0; linha < PQntuples(resultado); linha++) {
        for (int coluna = 0; coluna < 7; coluna++) {
            printf("%s%s", PQgetvalue(resultado, linha, coluna),
                   coluna == 6 ? "\n" : " | ");
        }
    }
    PQclear(resultado);
}

void painel_financeiro_mostrar(PGconn *conexao) {
    char entrada[32];
    int opcao = -1;

    do {
        PainelFinanceiro painel = {0};
        puts("\n==================================================");
        puts("  PAINEL FINANCEIRO");
        puts("==================================================");
        if (!consultar_resumo(conexao, &painel)) return;

        printf("Saldo atual da conta bancaria: R$ %s\n", painel.saldo_bancario);
        puts("1. Valor total pendente");
        puts("2. Parcelas vencidas");
        puts("3. Proximos vencimentos");
        puts("0. Voltar");
        printf("Escolha uma opcao: ");

        if (fgets(entrada, sizeof entrada, stdin) == NULL) return;
        if (sscanf(entrada, "%d", &opcao) != 1) opcao = -1;

        switch (opcao) {
            case 1:
                printf("Titulos em aberto: %s\n", painel.titulos_abertos);
                printf("Parcelas com saldo pendente: %s\n", painel.parcelas_abertas);
                printf("Valor total pendente: R$ %s\n", painel.total_pendente);
                listar_titulos_abertos(conexao);
                break;
            case 2:
                printf("Total vencido: R$ %s\n", painel.total_vencido);
                listar_parcelas(conexao, 0);
                break;
            case 3:
                printf("A vencer ate 30 dias: R$ %s\n", painel.total_ate_30_dias);
                printf("A vencer de 31 a 60 dias: R$ %s\n", painel.total_31_a_60_dias);
                printf("A vencer de 61 a 90 dias: R$ %s\n", painel.total_61_a_90_dias);
                puts(painel.saldo_cobre_ate_30_dias
                    ? "Saldo atual cobre os vencimentos ate 30 dias."
                    : "Atencao: saldo atual pode nao cobrir os vencimentos ate 30 dias.");
                listar_parcelas(conexao, 1);
                listar_parcelas(conexao, 2);
                listar_parcelas(conexao, 3);
                break;
            case 0:
                break;
            default:
                puts("Opcao invalida.");
                break;
        }
    } while (opcao != 0);
}
