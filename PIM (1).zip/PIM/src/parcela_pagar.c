#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parcela_pagar.h"

/*
 * Uma parcela e uma parte do titulo com seu proprio vencimento. Por exemplo,
 * um titulo de 300 reais pode ser dividido em tres parcelas de 100 reais.
 * Este modulo controla essas parcelas e seus vencimentos.
 */
static int ler_linha(const char *mensagem, char *destino, size_t tamanho) {
    printf("%s", mensagem);
    if (fgets(destino, (int)tamanho, stdin) == NULL) {
        return 0;
    }
    size_t tamanho_lido = strlen(destino);
    if (tamanho_lido > 0 && destino[tamanho_lido - 1] == '\n') {
        destino[--tamanho_lido] = '\0';
        if (tamanho_lido > 0 && destino[tamanho_lido - 1] == '\r') {
            destino[--tamanho_lido] = '\0';
        }
    } else {
        int caractere;
        while ((caractere = getchar()) != '\n' && caractere != EOF) {
        }
    }
    return 1;
}

/* Confere o formato da data e se aquele dia existe no calendario. */
static int data_calendario_valida(const char *data) {
    if (strlen(data) != 10 || data[4] != '-' || data[7] != '-') return 0;
    for (int i = 0; i < 10; i++) {
        if (i != 4 && i != 7 && (data[i] < '0' || data[i] > '9')) return 0;
    }
    int ano = (data[0] - '0') * 1000 + (data[1] - '0') * 100 +
              (data[2] - '0') * 10 + (data[3] - '0');
    int mes = (data[5] - '0') * 10 + (data[6] - '0');
    int dia = (data[8] - '0') * 10 + (data[9] - '0');
    if (ano == 0 || mes < 1 || mes > 12) return 0;
    int dias_no_mes[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (mes == 2 && (ano % 400 == 0 || (ano % 4 == 0 && ano % 100 != 0))) {
        dias_no_mes[1] = 29;
    }
    return dia >= 1 && dia <= dias_no_mes[mes - 1];
}

/* Recebe os dados da parcela e pede ao banco para inserir somente se o
 * titulo existir e ainda houver valor disponivel. O total ja dividido e
 * descontado do valor do titulo; a regra UNIQUE da tabela tambem impede
 * repetir o mesmo numero de parcela dentro de um titulo. */
static void cadastrar_parcela(PGconn *conexao) {
    ParcelaPagar parcela = {0};
    char entrada[32];
    char id_titulo[16];
    char numero_parcela[16];

    puts("\n--- Nova parcela ---");
    if (!ler_linha("ID do titulo existente: ", entrada, sizeof entrada) ||
        sscanf(entrada, "%d", &parcela.id_titulo_pagar) != 1 ||
        parcela.id_titulo_pagar <= 0) {
        puts("ID de titulo invalido.");
        return;
    }
    if (!ler_linha("Numero da parcela: ", entrada, sizeof entrada) ||
        sscanf(entrada, "%d", &parcela.numero_parcela) != 1 ||
        parcela.numero_parcela <= 0) {
        puts("Numero de parcela invalido.");
        return;
    }
    if (!ler_linha("Vencimento (AAAA-MM-DD): ", parcela.vencimento,
                   sizeof parcela.vencimento) || parcela.vencimento[0] == '\0' ||
        !ler_linha("Valor (use ponto decimal, ex.: 125.50): ", parcela.valor,
                   sizeof parcela.valor) || parcela.valor[0] == '\0') {
        puts("Vencimento e valor sao obrigatorios.");
        return;
    }
    if (!data_calendario_valida(parcela.vencimento)) {
        puts("Vencimento invalido. Confira dia e mes; use AAAA-MM-DD, por exemplo 2026-10-30.");
        return;
    }

    snprintf(id_titulo, sizeof id_titulo, "%d", parcela.id_titulo_pagar);
    snprintf(numero_parcela, sizeof numero_parcela, "%d", parcela.numero_parcela);
    const char *parametros[] = {
        id_titulo, numero_parcela, parcela.vencimento, parcela.valor
    };
    /* O INSERT SELECT so gera uma linha quando encontra o titulo e todas
     * as condicoes sao verdadeiras. A subconsulta SUM soma as parcelas
     * existentes; COALESCE usa zero se nao houver nenhuma. Com isso, o novo
     * valor fica limitado ao saldo ainda livre do titulo. */
    PGresult *resultado = PQexecParams(
        conexao,
        "INSERT INTO parcela_pagar "
        "(id_titulo_pagar, numero_parcela, vencimento, valor, status) "
        "SELECT $1::integer, $2::integer, $3::date, $4::numeric, 'pendente' "
        "FROM titulo_pagar t WHERE t.id_titulo_pagar = $1::integer "
        "AND $4::numeric > 0 AND $4::numeric <= t.valor_total - "
        "COALESCE((SELECT SUM(p.valor) FROM parcela_pagar p "
        "WHERE p.id_titulo_pagar = t.id_titulo_pagar), 0) "
        "RETURNING id_parcela_pagar",
        4, NULL, parametros, NULL, NULL, 0);

    if (PQresultStatus(resultado) == PGRES_TUPLES_OK && PQntuples(resultado) > 0) {
        parcela.id_parcela_pagar = atoi(PQgetvalue(resultado, 0, 0));
        printf("Parcela cadastrada. ID: %d\n", parcela.id_parcela_pagar);
    } else if (PQresultStatus(resultado) == PGRES_TUPLES_OK) {
        puts("O titulo nao existe, o valor e invalido ou a soma das parcelas ultrapassaria o titulo.");
    } else {
        fprintf(stderr, "Nao foi possivel cadastrar a parcela:\n%s",
                PQresultErrorMessage(resultado));
    }
    PQclear(resultado);
}

/* O total pago considera somente pagamentos realizados; cancelamentos ficam
   no historico, mas nao reduzem o saldo pendente da parcela. */
static void listar_parcelas(PGconn *conexao) {
    const char *sql =
        "SELECT p.id_parcela_pagar, p.id_titulo_pagar, p.numero_parcela, "
        "to_char(p.vencimento, 'YYYY-MM-DD'), p.valor, "
        "COALESCE(SUM(pg.valor_pago), 0), "
        "CASE WHEN COALESCE(SUM(pg.valor_pago), 0) >= p.valor THEN 'paga' "
        "WHEN p.vencimento < CURRENT_DATE THEN 'atrasada' "
        "WHEN COALESCE(SUM(pg.valor_pago), 0) > 0 THEN 'parcialmente paga' "
        "ELSE 'pendente' END "
        "FROM parcela_pagar p LEFT JOIN pagamento pg "
        "ON pg.id_parcela_pagar = p.id_parcela_pagar AND pg.status_pagamento = 'realizado' "
        "GROUP BY p.id_parcela_pagar ORDER BY p.vencimento, p.id_titulo_pagar";

    /* LEFT JOIN mantem parcelas ainda sem pagamento; SUM soma os valores
     * pagos e CASE define a situacao. GROUP BY permite calcular esse total
     * por parcela e ORDER BY organiza pela data mais proxima. */
    PGresult *resultado = PQexec(conexao, sql);
    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        fprintf(stderr, "Nao foi possivel consultar as parcelas:\n%s",
                PQresultErrorMessage(resultado));
        PQclear(resultado);
        return;
    }
    if (PQntuples(resultado) == 0) {
        puts("Ainda nao ha parcelas cadastradas.");
        PQclear(resultado);
        return;
    }

    puts("\nID | Titulo | Parcela | Vencimento | Valor | Pago | Situacao");
    puts("--------------------------------------------------------------------");
    for (int linha = 0; linha < PQntuples(resultado); linha++) {
        ParcelaPagar parcela = {0};
        parcela.id_parcela_pagar = atoi(PQgetvalue(resultado, linha, 0));
        parcela.id_titulo_pagar = atoi(PQgetvalue(resultado, linha, 1));
        parcela.numero_parcela = atoi(PQgetvalue(resultado, linha, 2));
        snprintf(parcela.vencimento, sizeof parcela.vencimento, "%s",
                 PQgetvalue(resultado, linha, 3));
        snprintf(parcela.valor, sizeof parcela.valor, "%s",
                 PQgetvalue(resultado, linha, 4));
        snprintf(parcela.status, sizeof parcela.status, "%s",
                 PQgetvalue(resultado, linha, 6));
        printf("%d | %d | %d | %s | %s | %s | %s\n",
               parcela.id_parcela_pagar, parcela.id_titulo_pagar,
               parcela.numero_parcela, parcela.vencimento, parcela.valor,
               PQgetvalue(resultado, linha, 5), parcela.status);
    }
    PQclear(resultado);
}

/* Permite editar apenas uma parcela sem pagamentos vinculados, para nao
 * alterar dados que ja aparecem no historico. O SQL exclui a propria parcela
 * da soma das demais e verifica se o novo valor cabe no total livre do titulo. */
static void alterar_parcela(PGconn *conexao) {
    ParcelaPagar parcela = {0};
    char entrada[32];
    char id_parcela[16];
    char numero_parcela[16];

    if (!ler_linha("ID da parcela que deseja alterar: ", entrada, sizeof entrada) ||
        sscanf(entrada, "%d", &parcela.id_parcela_pagar) != 1 ||
        parcela.id_parcela_pagar <= 0) {
        puts("ID de parcela invalido.");
        return;
    }
    if (!ler_linha("Novo numero da parcela: ", entrada, sizeof entrada) ||
        sscanf(entrada, "%d", &parcela.numero_parcela) != 1 ||
        parcela.numero_parcela <= 0) {
        puts("Numero de parcela invalido.");
        return;
    }
    if (!ler_linha("Novo vencimento (AAAA-MM-DD): ", parcela.vencimento,
                   sizeof parcela.vencimento) || parcela.vencimento[0] == '\0' ||
        !ler_linha("Novo valor (use ponto decimal): ", parcela.valor,
                   sizeof parcela.valor) || parcela.valor[0] == '\0') {
        puts("Vencimento e valor sao obrigatorios.");
        return;
    }
    if (!data_calendario_valida(parcela.vencimento)) {
        puts("Vencimento invalido. Confira dia e mes; use AAAA-MM-DD, por exemplo 2026-10-30.");
        return;
    }

    snprintf(id_parcela, sizeof id_parcela, "%d", parcela.id_parcela_pagar);
    snprintf(numero_parcela, sizeof numero_parcela, "%d", parcela.numero_parcela);
    const char *parametros[] = {
    numero_parcela, parcela.vencimento, parcela.valor, id_parcela
};
    /* Os parametros substituem os marcadores $1 a $4.
 * A subconsulta soma as outras parcelas do titulo, sem contar a parcela
 * que esta sendo editada; NOT EXISTS bloqueia a alteracao se houver pagamento ligado. */
PGresult *resultado = PQexecParams(
    conexao,
    "UPDATE parcela_pagar "
    "SET numero_parcela = $1::integer, "
    "vencimento = $2::date, "
    "valor = $3::numeric, "
    "status = 'pendente' "
    "WHERE id_parcela_pagar = $4::integer "
    "AND $3::numeric > 0 "
    "AND $3::numeric <= ("
        "SELECT t.valor_total - COALESCE(SUM(p.valor), 0) "
        "FROM parcela_pagar atual "
        "JOIN titulo_pagar t "
        "ON t.id_titulo_pagar = atual.id_titulo_pagar "
        "LEFT JOIN parcela_pagar p "
        "ON p.id_titulo_pagar = t.id_titulo_pagar "
        "AND p.id_parcela_pagar <> atual.id_parcela_pagar "
        "WHERE atual.id_parcela_pagar = $4::integer "
        "GROUP BY t.valor_total"
    ") "
    "AND NOT EXISTS ("
        "SELECT 1 FROM pagamento "
        "WHERE pagamento.id_parcela_pagar = parcela_pagar.id_parcela_pagar"
    ") "
    "RETURNING id_parcela_pagar",
    4, NULL, parametros, NULL, NULL, 0);

    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        fprintf(stderr, "Nao foi possivel alterar. Verifique o numero, o vencimento e o valor:\n%s",
                PQresultErrorMessage(resultado));
    } else if (PQntuples(resultado) == 0) {
        puts("Parcela nao encontrada, possui pagamento, ou o valor excede o saldo do titulo.");
    } else {
        puts("Parcela alterada com sucesso.");
    }
    PQclear(resultado);
}

/* O DELETE so encontra parcelas sem pagamentos associados. Essa condicao
 * preserva a ligacao usada pelo historico financeiro. */
static void excluir_parcela(PGconn *conexao) {
    char entrada[32];
    char confirmacao[8];
    int id_parcela;

    if (!ler_linha("ID da parcela que deseja excluir: ", entrada, sizeof entrada) ||
        sscanf(entrada, "%d", &id_parcela) != 1 || id_parcela <= 0) {
        puts("ID de parcela invalido.");
        return;
    }
    if (!ler_linha("Confirma a exclusao? (s/n): ", confirmacao, sizeof confirmacao) ||
        (confirmacao[0] != 's' && confirmacao[0] != 'S')) {
        puts("Exclusao cancelada.");
        return;
    }

    snprintf(entrada, sizeof entrada, "%d", id_parcela);
    const char *parametros[] = {entrada};
    PGresult *resultado = PQexecParams(
        conexao,
        "DELETE FROM parcela_pagar WHERE id_parcela_pagar = $1::integer "
        "AND NOT EXISTS (SELECT 1 FROM pagamento "
        "WHERE pagamento.id_parcela_pagar = parcela_pagar.id_parcela_pagar) "
        "RETURNING id_parcela_pagar",
        1, NULL, parametros, NULL, NULL, 0);

    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        fprintf(stderr, "Nao foi possivel excluir a parcela:\n%s", PQresultErrorMessage(resultado));
    } else if (PQntuples(resultado) == 0) {
        puts("Parcela nao encontrada ou ja possui pagamento registrado.");
    } else {
        puts("Parcela excluida com sucesso.");
    }
    PQclear(resultado);
}
void parcela_pagar_menu(PGconn *conexao) {
    char entrada[32];
    int opcao = -1;

    do {
        puts("\n==================================================");
        puts("  PARCELAS A PAGAR");
        puts("==================================================");
        puts("1. Cadastrar parcela para titulo existente\n2. Consultar parcelas\n3. Alterar parcela\n4. Excluir parcela\n0. Voltar");
        printf("Escolha uma opcao: ");

        if (fgets(entrada, sizeof entrada, stdin) == NULL) {
            return;
        }
        if (sscanf(entrada, "%d", &opcao) != 1) {
            opcao = -1;
        }
        switch (opcao) {
            case 1: cadastrar_parcela(conexao); break;
            case 2: listar_parcelas(conexao); break;
            case 3: alterar_parcela(conexao); break;
            case 4: excluir_parcela(conexao); break;
            case 0: break;
            default: puts("Opcao invalida."); break;
        }
    } while (opcao != 0);
}




