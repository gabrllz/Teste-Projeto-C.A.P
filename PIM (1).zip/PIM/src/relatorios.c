#include <stdio.h>
#include <string.h>
#include "relatorios.h"

/*
 * Este modulo gera relatorios para um periodo escolhido pelo usuario. Cada
 * relatorio usa uma data diferente: dia do pagamento, emissao do titulo,
 * competencia da despesa ou vencimento da parcela.
 */
typedef struct {
    char data_inicio[11];
    char data_fim[11];
} PeriodoRelatorio;

static int ler_linha(const char *mensagem, char *destino, size_t tamanho) {
    printf("%s", mensagem);
    if (fgets(destino, (int)tamanho, stdin) == NULL) return 0;

    size_t comprimento = strlen(destino);
    if (comprimento > 0 && destino[comprimento - 1] == '\n') {
        destino[--comprimento] = '\0';
        if (comprimento > 0 && destino[comprimento - 1] == '\r') {
            destino[--comprimento] = '\0';
        }
    } else {
        int caractere;
        while ((caractere = getchar()) != '\n' && caractere != EOF) {
        }
    }
    return 1;
}

/* Confere o formato AAAA-MM-DD, se o dia existe naquele mes e considera
 * o dia extra de fevereiro nos anos bissextos. */
static int data_calendario_valida(const char *data) {
    if (strlen(data) != 10 || data[4] != '-' || data[7] != '-') return 0;
    for (int i = 0; i < 10; i++) {
        if (i != 4 && i != 7 && (data[i] < '0' || data[i] > '9')) return 0;
    }

    int ano = (data[0] - '0') * 1000 + (data[1] - '0') * 100 +
              (data[2] - '0') * 10 + (data[3] - '0');
    int mes = (data[5] - '0') * 10 + (data[6] - '0');
    int dia = (data[8] - '0') * 10 + (data[9] - '0');
    if (ano == 0 || mes < 1 || mes > 12) return 0;

    int dias_no_mes[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (mes == 2 && (ano % 400 == 0 || (ano % 4 == 0 && ano % 100 != 0))) {
        dias_no_mes[1] = 29;
    }
    return dia >= 1 && dia <= dias_no_mes[mes - 1];
}

/* Pede inicio e fim do periodo, valida se ambas sao datas reais e impede
 * que o inicio fique depois do fim. Essas datas serao enviadas como
 * parametros para filtrar cada relatorio. */
static int ler_periodo(PeriodoRelatorio *periodo) {
    /* Os relatorios usam um intervalo de datas informado pelo usuario. */
    puts("Informe as datas no formato AAAA-MM-DD.");
    if (!ler_linha("Data inicial: ", periodo->data_inicio,
                   sizeof periodo->data_inicio) ||
        !ler_linha("Data final: ", periodo->data_fim,
                   sizeof periodo->data_fim)) {
        puts("Leitura das datas interrompida.");
        return 0;
    }
    if (!data_calendario_valida(periodo->data_inicio) ||
        !data_calendario_valida(periodo->data_fim)) {
        puts("Data invalida. Confira dia e mes e use AAAA-MM-DD.");
        return 0;
    }
    if (strcmp(periodo->data_inicio, periodo->data_fim) > 0) {
        puts("A data inicial deve ser anterior ou igual a data final.");
        return 0;
    }
    return 1;
}

/* Reutiliza esta rotina para todos os relatorios: envia as datas como
 * parametros, verifica se o SELECT funcionou, mostra os nomes das colunas
 * e percorre as linhas que o banco retornou. */
static void executar_relatorio(PGconn *conexao, const char *sql,
                               const char *titulo, const char *rotulos[],
                               int quantidade_colunas,
                               const PeriodoRelatorio *periodo) {
    const char *parametros[] = {periodo->data_inicio, periodo->data_fim};
    PGresult *resultado = PQexecParams(conexao, sql, 2, NULL, parametros,
                                       NULL, NULL, 0);
    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        fprintf(stderr, "Nao foi possivel gerar o relatorio:\n%s",
                PQresultErrorMessage(resultado));
        PQclear(resultado);
        return;
    }
    if (PQntuples(resultado) == 0) {
        printf("\n%s\nNao ha registros nesse periodo.\n", titulo);
        PQclear(resultado);
        return;
    }

    printf("\n%s\n", titulo);
    for (int coluna = 0; coluna < quantidade_colunas; coluna++) {
        printf("%s%s", rotulos[coluna],
               coluna == quantidade_colunas - 1 ? "\n" : " | ");
    }
    for (int linha = 0; linha < PQntuples(resultado); linha++) {
        for (int coluna = 0; coluna < quantidade_colunas; coluna++) {
            printf("%s%s", PQgetvalue(resultado, linha, coluna),
                   coluna == quantidade_colunas - 1 ? "\n" : " | ");
        }
    }
    PQclear(resultado);
}

/* Filtra pela data do pagamento e junta os dados da parcela, titulo,
 * fornecedor e forma usada. Inclui tambem pagamentos cancelados e seus
 * motivos para que o relatorio preserve o historico dos estornos. */
static void relatorio_pagamentos(PGconn *conexao) {
    PeriodoRelatorio periodo;
    if (!ler_periodo(&periodo)) return;

    const char *sql =
        "SELECT to_char(pg.data_pagamento, 'YYYY-MM-DD HH24:MI'), "
        "pg.id_pagamento, t.id_titulo_pagar, f.razao_social, "
        "p.numero_parcela, pg.valor_pago, fp.descricao, "
        "pg.status_pagamento, COALESCE(pg.motivo_cancelamento, '-') "
        "FROM pagamento pg "
        "JOIN parcela_pagar p ON p.id_parcela_pagar = pg.id_parcela_pagar "
        "JOIN titulo_pagar t ON t.id_titulo_pagar = p.id_titulo_pagar "
        "JOIN fornecedor f ON f.id_fornecedor = t.id_fornecedor "
        "JOIN forma_pagamento fp ON fp.id_forma_pagamento = pg.id_forma_pagamento "
        "WHERE pg.data_pagamento::date BETWEEN $1::date AND $2::date "
        "ORDER BY pg.data_pagamento, pg.id_pagamento";
    const char *rotulos[] = {
        "Data do pagamento", "ID pagamento", "ID titulo", "Fornecedor",
        "Parcela", "Valor", "Forma", "Status", "Motivo"
    };
    executar_relatorio(conexao, sql, "Pagamentos registrados no periodo",
                       rotulos, 9, &periodo);
}

/* Aplica o periodo a data de emissao do titulo e relaciona o fornecedor
 * para que cada registro possa ser identificado no relatorio. */
static void relatorio_titulos(PGconn *conexao) {
    PeriodoRelatorio periodo;
    if (!ler_periodo(&periodo)) return;

    const char *sql =
        "SELECT t.id_titulo_pagar, f.razao_social, "
        "to_char(t.data_emissao, 'YYYY-MM-DD'), t.valor_total, t.status "
        "FROM titulo_pagar t JOIN fornecedor f "
        "ON f.id_fornecedor = t.id_fornecedor "
        "WHERE t.data_emissao BETWEEN $1::date AND $2::date "
        "ORDER BY t.data_emissao, t.id_titulo_pagar";
    const char *rotulos[] = {"ID titulo", "Fornecedor", "Emissao", "Valor", "Status"};
    executar_relatorio(conexao, sql, "Titulos emitidos no periodo",
                       rotulos, 5, &periodo);
}

/* Filtra pela data de competencia e agrupa as despesas por tipo.
 * COUNT conta quantas despesas existem em cada grupo e SUM soma seus valores. */
static void relatorio_despesas(PGconn *conexao) {
    PeriodoRelatorio periodo;
    if (!ler_periodo(&periodo)) return;

    const char *sql =
        "SELECT tipo_despesa, COUNT(*), SUM(valor) "
        "FROM despesa WHERE data_competencia BETWEEN $1::date AND $2::date "
        "GROUP BY tipo_despesa ORDER BY tipo_despesa";
    const char *rotulos[] = {"Tipo", "Quantidade", "Total"};
    executar_relatorio(conexao, sql, "Despesas por competencia no periodo",
                       rotulos, 3, &periodo);
}

/* Filtra parcelas pelo vencimento. LEFT JOIN mantem parcelas sem pagamento;
 * SUM calcula o total pago e COALESCE troca ausencia de pagamentos por zero.
 * CASE calcula a situacao e pagamentos cancelados ficam fora da soma. */
static void relatorio_parcelas(PGconn *conexao) {
    PeriodoRelatorio periodo;
    if (!ler_periodo(&periodo)) return;

    const char *sql =
        "SELECT t.id_titulo_pagar, f.razao_social, "
        "p.numero_parcela, to_char(p.vencimento, 'YYYY-MM-DD'), p.valor, "
        "COALESCE(SUM(pg.valor_pago), 0), "
        "p.valor - COALESCE(SUM(pg.valor_pago), 0), "
        "CASE WHEN p.valor - COALESCE(SUM(pg.valor_pago), 0) <= 0 THEN 'paga' "
        "WHEN p.vencimento < CURRENT_DATE THEN 'atrasada' "
        "WHEN COALESCE(SUM(pg.valor_pago), 0) > 0 THEN 'parcialmente paga' "
        "ELSE 'pendente' END "
        "FROM parcela_pagar p "
        "JOIN titulo_pagar t ON t.id_titulo_pagar = p.id_titulo_pagar "
        "JOIN fornecedor f ON f.id_fornecedor = t.id_fornecedor "
        "LEFT JOIN pagamento pg ON pg.id_parcela_pagar = p.id_parcela_pagar "
        "AND pg.status_pagamento = 'realizado' "
        "WHERE p.vencimento BETWEEN $1::date AND $2::date "
        "GROUP BY t.id_titulo_pagar, f.razao_social, p.id_parcela_pagar "
        "ORDER BY p.vencimento, t.id_titulo_pagar, p.numero_parcela";
    const char *rotulos[] = {
        "ID titulo", "Fornecedor", "Parcela", "Vencimento", "Valor",
        "Pago", "Restante", "Situacao"
    };
    executar_relatorio(conexao, sql, "Parcelas por vencimento no periodo",
                       rotulos, 8, &periodo);
}

void relatorios_menu(PGconn *conexao) {
    char entrada[32];
    int opcao = -1;

    do {
        puts("\n==================================================");
        puts("  RELATORIOS");
        puts("==================================================");
        puts("1. Pagamentos no periodo");
        puts("2. Titulos emitidos no periodo");
        puts("3. Despesas fixas e variaveis");
        puts("4. Parcelas por vencimento");
        puts("0. Voltar");
        printf("Escolha uma opcao: ");

        if (fgets(entrada, sizeof entrada, stdin) == NULL) return;
        if (sscanf(entrada, "%d", &opcao) != 1) opcao = -1;

        switch (opcao) {
            case 1: relatorio_pagamentos(conexao); break;
            case 2: relatorio_titulos(conexao); break;
            case 3: relatorio_despesas(conexao); break;
            case 4: relatorio_parcelas(conexao); break;
            case 0: break;
            default: puts("Opcao invalida."); break;
        }
    } while (opcao != 0);
}
