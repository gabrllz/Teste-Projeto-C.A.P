#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "titulo_pagar.h"

/*
 * Este menu consulta titulos a pagar criados pelo modulo de Compras. Os dados
 * do fornecedor e do pedido pertencem a outros modulos e ajudam a identificar
 * de onde veio cada titulo.
 */
/* Copia um texto para um vetor com limite de tamanho; se origem for NULL,
 * guarda texto vazio para evitar usar um ponteiro nulo. */
static void copiar_texto(char *destino, size_t tamanho, const char *origem) {
    snprintf(destino, tamanho, "%s", origem == NULL ? "" : origem);
}

/* Consulta os titulos criados pelo modulo de Compras; nao cria nem altera
 * registros dessa tabela. O resultado inclui fornecedor e origem do titulo. */
static void listar_titulos(PGconn *conexao) {
    /* Esta consulta e somente de leitura: relaciona titulo e fornecedor e
     * mostra se a origem e um pedido ou uma despesa. COALESCE substitui IDs
     * opcionais ausentes por um traco; ORDER BY organiza pela emissao. */
    const char *sql =
        "SELECT t.id_titulo_pagar, t.id_fornecedor, "
        "f.razao_social, "
        "COALESCE(t.id_pedido_compra::text, '-'), "
        "COALESCE(t.id_despesa::text, '-'), "
        "to_char(t.data_emissao, 'YYYY-MM-DD'), t.valor_total, t.status "
        "FROM titulo_pagar t "
        "JOIN fornecedor f ON f.id_fornecedor = t.id_fornecedor "
        "ORDER BY t.data_emissao, t.id_titulo_pagar";

    PGresult *resultado = PQexec(conexao, sql);
    if (PQresultStatus(resultado) != PGRES_TUPLES_OK) {
        fprintf(stderr, "Nao foi possivel consultar os titulos:\n%s",
                PQresultErrorMessage(resultado));
        PQclear(resultado);
        return;
    }
    if (PQntuples(resultado) == 0) {
        puts("Ainda nao ha titulos a pagar cadastrados.");
        PQclear(resultado);
        return;
    }

    puts("\nID | Fornecedor | Pedido | Despesa | Emissao | Valor | Status");
    puts("-----------------------------------------------------------------------");
    for (int linha = 0; linha < PQntuples(resultado); linha++) {
        TituloPagar titulo = {0};
        titulo.id_titulo_pagar = atoi(PQgetvalue(resultado, linha, 0));
        titulo.id_fornecedor = atoi(PQgetvalue(resultado, linha, 1));
        titulo.id_pedido_compra = strcmp(PQgetvalue(resultado, linha, 3), "-") == 0
            ? 0 : atoi(PQgetvalue(resultado, linha, 3));
        titulo.id_despesa = strcmp(PQgetvalue(resultado, linha, 4), "-") == 0
            ? 0 : atoi(PQgetvalue(resultado, linha, 4));
        copiar_texto(titulo.data_emissao, sizeof titulo.data_emissao,
                     PQgetvalue(resultado, linha, 5));
        copiar_texto(titulo.valor_total, sizeof titulo.valor_total,
                     PQgetvalue(resultado, linha, 6));
        copiar_texto(titulo.status, sizeof titulo.status,
                     PQgetvalue(resultado, linha, 7));

        printf("%d | %s | %s | %s | %s | %s | %s\n",
               titulo.id_titulo_pagar,
               PQgetvalue(resultado, linha, 2),
               titulo.id_pedido_compra == 0 ? "-" : PQgetvalue(resultado, linha, 3),
               titulo.id_despesa == 0 ? "-" : PQgetvalue(resultado, linha, 4),
               titulo.data_emissao,
               titulo.valor_total,
               titulo.status);
    }
    PQclear(resultado);
}

void titulo_pagar_menu(PGconn *conexao) {
    char entrada[32];
    int opcao = -1;

    do {
        puts("\n==================================================");
        puts("  TITULOS A PAGAR");
        puts("==================================================");
        puts("1. Consultar titulos\n0. Voltar");
        printf("Escolha uma opcao: ");

        if (fgets(entrada, sizeof entrada, stdin) == NULL) {
            return;
        }
        if (sscanf(entrada, "%d", &opcao) != 1) {
            opcao = -1;
        }

        switch (opcao) {
            case 1: listar_titulos(conexao); break;
            case 0: break;
            default: puts("Opcao invalida."); break;
        }
    } while (opcao != 0);
}
